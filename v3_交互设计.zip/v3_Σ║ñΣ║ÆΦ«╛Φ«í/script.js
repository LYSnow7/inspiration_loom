// --- 全局状态管理 ---
// 用一个对象来管理整个应用的状态，替代 React 的 useState
const state = {
    stage: 'intro', // 当前阶段: 'intro', 'setup', 'weaving', 'result'
    warp: { era: null, world: null, style: null }, // 经线 (故事框架)
    characters: [], // 角色列表
    plots: [], // 情节列表
    storyText: "", // 生成的故事文本
};

// --- DOM 节点 ---
const app = document.getElementById('app');

// --- SVG 图标 ---
// 将 React 组件转换为返回 SVG 字符串的函数
const ICONS = {
    SPINDLE: (props) => `<svg ${props} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" xmlns="http://www.w3.org/2000/svg"><path d="M12 2L15 5L12 8L9 5L12 2Z" stroke-linejoin="round"/><path d="M12 22L15 19L12 16L9 19L12 22Z" stroke-linejoin="round"/><path d="M5 15L2 12L5 9" stroke-linejoin="round"/><path d="M19 15L22 12L19 9" stroke-linejoin="round"/><path d="M12 8V16" /><path d="M15 5C17.5 7.5 17.5 16.5 15 19" /><path d="M9 5C6.5 7.5 6.5 16.5 9 19" /></svg>`,
    SHUTTLE: (props) => `<svg ${props} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2 32C2 32 12 4 32 4C52 4 62 32 62 32C62 32 52 60 32 60C12 60 2 32 2 32Z" stroke="currentColor" stroke-width="3" /><circle cx="32" cy="32" r="8" fill="currentColor" /></svg>`,
    THREAD: (props) => `<svg ${props} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 3C12 3 6 4.5 6 9C6 13.5 12 15 12 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M12 15C12 15 18 16.5 18 21C18 25.5 12 27 12 27" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" opacity="0.6"/><path d="M12 15C12 15 6 16.5 6 21C6 25.5 12 27 12 27" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" opacity="0.6"/><path d="M12 3C12 3 18 4.5 18 9C18 13.5 12 15 12 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
    TEXTURE: (props) => `<svg ${props} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" xmlns="http://www.w3.org/2000/svg"><path d="M3 5.2C3 5.2 4.2 4 6 4C7.8 4 9 5.2 9 5.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 12C3 12 4.2 10.8 6 10.8C7.8 10.8 9 12 9 12" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 18.8C3 18.8 4.2 17.6 6 17.6C7.8 17.6 9 18.8 9 18.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 5.2C15 5.2 16.2 4 18 4C19.8 4 21 5.2 21 5.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 12C15 12 16.2 10.8 18 10.8C19.8 10.8 21 12 21 12" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 18.8C15 18.8 16.2 17.6 18 17.6C19.8 17.6 21 18.8 21 18.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
};

// --- 数据 (已更新) ---
const WARP_OPTIONS = {
    era: [
        { name: "远古洪荒", icon: "🦖", description: "巨兽漫步，神话初生" },
        { name: "奇幻中世纪", icon: "🏰", description: "骑士与魔法，龙与传说" },
        { name: "武侠江湖", icon: "🗡️", description: "刀光剑影，快意恩仇" },
        { name: "蒸汽朋克", icon: "⚙️", description: "齿轮与奥秘，工业的轰鸣" },
        { name: "现代都市", icon: "🏢", description: "车水马龙，霓虹下的罪与爱" },
        { name: "赛博纪元", icon: "🌃", description: "霓虹与义体，高科技低生活" },
        { name: "末日废土", icon: "☢️", description: "文明的余烬，生存的挣扎" },
        { name: "星际未来", icon: "🚀", description: "深空探索，文明的碰撞" },
    ],
    world: [
        { name: "失落的古城", icon: "🏛️", description: "被遗忘的文明遗迹" },
        { name: "无尽的沙漠", icon: "🏜️", description: "烈日与流沙下的秘密" },
        { name: "浮空的岛屿", icon: "🏝️", description: "云海之上的奇迹国度" },
        { name: "幽深的森林", icon: "🌳", description: "古老树木间的精灵低语" },
        { name: "深海王国", icon: "🐠", description: "珊瑚与宫殿，遗忘的旋律" },
        { name: "云顶天宫", icon: "☁️", description: "仙雾缭绕，众神的居所" },
        { name: "机械都市", icon: "🤖", description: "精准与冰冷，秩序的堡垒" },
        { name: "繁华的都市", icon: "🏙️", description: "钢铁丛林中的万千故事" },
    ],
    style: [
        { name: "悬疑", icon: "❓", color: "from-indigo-400 to-slate-700" },
        { name: "浪漫", icon: "❤️", color: "from-rose-400 to-red-500" },
        { name: "史诗", icon: "⚔️", color: "from-amber-400 to-orange-600" },
        { name: "治愈", icon: "✨", color: "from-emerald-300 to-teal-500" },
        { name: "科幻", icon: "👩‍🚀", color: "from-sky-400 to-indigo-600" },
        { name: "喜剧", icon: "😂", color: "from-yellow-300 to-green-400" },
        { name: "哲理", icon: "🧠", color: "from-slate-400 to-gray-500" },
        { name: "恐怖", icon: "👻", color: "from-gray-700 to-black" },
    ],
};

const KEYWORD_COLORS = [ 'text-red-400', 'text-blue-400', 'text-green-400', 'text-yellow-400', 'text-purple-400', 'text-pink-400', 'text-indigo-400', 'text-teal-400', 'text-orange-400' ];
const getKeywordColor = (str) => {
    let hash = 0;
    for (let i = 0; i < str.length; i++) { hash = str.charCodeAt(i) + ((hash << 5) - hash); }
    return KEYWORD_COLORS[Math.abs(hash) % KEYWORD_COLORS.length];
};

// --- 渲染函数 ---

/**
 * 主渲染函数，根据 state.stage 决定显示哪个界面
 */
function render() {
    // 清空主容器
    app.innerHTML = '';
    // 根据当前阶段渲染对应内容
    switch (state.stage) {
        case 'intro':
            renderIntro();
            break;
        case 'setup':
            renderSetup();
            break;
        case 'weaving':
            renderWeavingArea();
            break;
        case 'result':
            renderResult();
            break;
    }
}

function renderIntro() {
    // 动画HTML，已移除文字圈
    const introHTML = `
        <div id="intro-container" class="fixed inset-0 bg-slate-900 flex flex-col justify-center items-center transition-opacity duration-1000 opacity-100">
            <div class="relative w-80 h-80 flex justify-center items-center">
                <div id="loom-icon" class="transition-all duration-1000 opacity-0 scale-90">
                    <div class="w-64 h-64 border-4 border-amber-300 rounded-lg flex flex-col justify-between p-4 relative">
                       ${Array(7).fill(0).map((_, i) => `<div class="absolute h-full w-px bg-amber-200 opacity-50 top-0" style="left: ${(i+1)*12.5}%"></div>`).join('')}
                       <div class="w-full h-1 bg-amber-400 rounded-full"></div>
                         <p class="text-center text-amber-100 text-3xl font-serif mt-10">灵感织机</p>
                       <div class="w-full h-1 bg-amber-400 rounded-full"></div>
                    </div>
                </div>
            </div>
            <h1 id="slogan" class="mt-12 text-2xl font-serif text-slate-200 transition-opacity duration-1000 opacity-0">
                编织属于你的叙事纹理
            </h1>
        </div>
    `;
    app.innerHTML = introHTML;

    // 新的简化版动画逻辑
    setTimeout(() => {
        const loomIcon = document.getElementById('loom-icon');
        const slogan = document.getElementById('slogan');

        if (loomIcon && slogan) {
            // 让织机图标和口号淡入并放大
            loomIcon.classList.replace('opacity-0', 'opacity-100');
            loomIcon.classList.replace('scale-90', 'scale-100');
            slogan.classList.replace('opacity-0', 'opacity-100');
        }
    }, 500); // 延迟500毫秒后开始动画

    // 设置一个定时器，在4秒后过渡到下一个阶段
    setTimeout(() => {
        const introContainer = document.getElementById('intro-container');
        if (introContainer) {
            introContainer.classList.replace('opacity-100', 'opacity-0');
        }
        // 在淡出动画结束后，渲染设置界面
        setTimeout(() => {
            state.stage = 'setup';
            render();
        }, 1000); // 等待淡出动画完成
    }, 4000); // 动画总时长为4秒
}


function renderSetup(step = 0) {
    const steps = [
        { title: "第一步: 选择时代经线", category: "era", options: WARP_OPTIONS.era, prompt: "故事发生在哪个时代？" },
        { title: "第二步: 设定世界经线", category: "world", options: WARP_OPTIONS.world, prompt: "它的舞台在何处？" },
        { title: "第三步: 定义故事纹理", category: "style", options: WARP_OPTIONS.style, prompt: "你希望它呈现何种质感？" }
    ];
    
    if (step >= steps.length) {
        state.stage = 'weaving';
        render();
        return;
    }

    const currentStep = steps[step];
    const setupHTML = `
        <div class="min-h-screen w-full text-slate-200 flex flex-col justify-center items-center p-4">
            <div class="text-center w-full max-w-7xl animate-fade-in">
                <p class="text-amber-300 font-serif mb-2">${currentStep.title}</p>
                <h2 class="text-4xl font-serif mb-12">${currentStep.prompt}</h2>
                <div class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-4 md:gap-6">
                    ${currentStep.options.map(option => `
                        <div class="relative group flex justify-center">
                            <button class="setup-option aspect-square bg-slate-800/50 border border-slate-700 rounded-xl flex flex-col justify-center items-center p-4 hover:bg-slate-700 hover:border-amber-400 hover:scale-105 transition-all duration-300"
                                    data-category="${currentStep.category}" data-value='${JSON.stringify(option)}'>
                                <span class="text-5xl mb-2">${option.icon}</span>
                                <span class="font-serif text-lg text-center">${option.name}</span>
                            </button>
                            <div class="absolute bottom-full mb-2 w-max px-3 py-1.5 text-sm text-white bg-gray-800 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                                ${option.description || option.name}
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
            <div class="fixed bottom-8 flex space-x-4">
                ${steps.map((s, i) => `<div class="w-3 h-3 rounded-full transition-colors duration-300 ${step >= i ? 'bg-amber-400' : 'bg-slate-600'}"></div>`).join('')}
            </div>
        </div>
    `;
    app.innerHTML = setupHTML;
    
    // 添加事件监听器
    document.querySelectorAll('.setup-option').forEach(button => {
        button.addEventListener('click', (e) => {
            const target = e.currentTarget;
            const category = target.dataset.category;
            const value = JSON.parse(target.dataset.value);
            state.warp[category] = value;
            setTimeout(() => renderSetup(step + 1), 300);
        });
    });
}


// 更多渲染函数和逻辑...
function renderWeavingArea() {
    let shuttleContent = { plot: null, chars: [] };

    // Function to re-render the shuttle area
    function updateShuttleView() {
        const shuttleArea = document.getElementById('shuttle-area');
        if (shuttleArea) {
            shuttleArea.innerHTML = `
                <p class="text-slate-400 text-sm mb-1">将情节与角色拖入梭中</p>
                ${shuttleContent.plot ? `<p class="text-amber-300 text-xs truncate">情节: ${shuttleContent.plot.description}</p>` : ''}
                ${shuttleContent.chars.length > 0 ? `<p class="text-cyan-300 text-xs truncate">角色: ${shuttleContent.chars.map(c => c.name).join(', ')}</p>` : ''}
            `;
            const shuttleIcon = document.getElementById('shuttle-icon-main');
            if (shuttleIcon) {
                if (shuttleContent.plot) {
                    shuttleIcon.classList.add('text-amber-400');
                } else {
                    shuttleIcon.classList.remove('text-amber-400');
                }
            }
        }
    }
    
    const weavingHTML = `
        <div class="flex flex-col md:flex-row h-screen p-4 md:p-6 gap-6 text-slate-200">
            <!-- Left Panel: Spindles -->
            <div class="w-full md:w-96 bg-slate-800/70 backdrop-blur-sm p-4 rounded-lg border border-slate-700 flex-shrink-0 flex flex-col gap-6 overflow-y-auto no-scrollbar">
                <div>
                    <h3 class="text-xl font-serif text-amber-300 flex items-center gap-2 mb-3">${ICONS.SPINDLE('class="w-6 h-6"')} 角色纺锤</h3>
                    <form id="add-char-form" class="flex gap-2">
                        <input type="text" id="char-name-input" placeholder="新角色名" class="flex-grow bg-slate-900 border border-slate-600 rounded-md px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-amber-400" />
                        <button type="submit" class="bg-amber-500 text-slate-900 font-bold rounded-md px-3 py-1.5 hover:bg-amber-400 transition-colors">添加</button>
                    </form>
                    <div id="characters-list" class="mt-4 space-y-3"></div>
                </div>
                <div>
                    <h3 class="text-xl font-serif text-amber-300 flex items-center gap-2 mb-3">${ICONS.THREAD('class="w-6 h-6"')} 情节纺锤</h3>
                    <form id="add-plot-form" class="flex gap-2">
                        <input type="text" id="plot-desc-input" placeholder="新情节纬线" class="flex-grow bg-slate-900 border border-slate-600 rounded-md px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-amber-400" />
                        <button type="submit" class="bg-amber-500 text-slate-900 font-bold rounded-md px-3 py-1.5 hover:bg-amber-400 transition-colors">添加</button>
                    </form>
                    <div id="plots-list" class="mt-4 space-y-2"></div>
                </div>
            </div>

            <!-- Right Panel: Weaving Area -->
            <div class="flex-grow flex flex-col items-center justify-between p-6 bg-slate-900/50 rounded-lg border border-slate-700">
                <div class="relative w-full h-24 mb-6">
                     <div class="absolute inset-0 flex justify-around items-center">
                        ${Array(9).fill(0).map((_, i) => `<div class="w-px h-full bg-gradient-to-b from-transparent via-amber-300/50 to-transparent"></div>`).join('')}
                    </div>
                    <div class="absolute inset-0 flex flex-col justify-between">
                       <div class="h-1 rounded-full bg-gradient-to-r ${state.warp.style.color}"></div>
                       <div class="text-center py-2">
                           <p class="font-serif text-slate-300">${state.warp.era.name} | ${state.warp.world.name}</p>
                           <p class="text-xs text-slate-400">故事纹理: ${state.warp.style.name}</p>
                       </div>
                       <div class="h-1 rounded-full bg-gradient-to-r ${state.warp.style.color}"></div>
                    </div>
                </div>

                <div id="draggable-sources" class="w-full mb-6"></div>
                
                <div id="droppable-shuttle" class="relative flex flex-col items-center justify-center p-6 border-2 border-dashed rounded-2xl transition-all duration-300 border-slate-600">
                    ${ICONS.SHUTTLE('id="shuttle-icon-main" class="w-32 h-32 text-slate-500 transition-colors duration-300"')}
                    <div id="shuttle-area" class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 text-center pointer-events-none">
                        <!-- shuttle content here -->
                    </div>
                </div>

                <button id="weave-button" class="mt-8 w-full max-w-sm flex items-center justify-center gap-3 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-900 font-bold text-xl py-4 rounded-lg shadow-lg hover:shadow-amber-500/30 transition-all duration-300">
                    ${ICONS.SHUTTLE('class="w-7 h-7"')} 引梭织布
                </button>
            </div>
        </div>
    `;
    app.innerHTML = weavingHTML;
    
    // --- Update UI functions ---
    function renderCharacters() {
        const list = document.getElementById('characters-list');
        list.innerHTML = state.characters.map(char => `
            <div class="bg-slate-900/50 p-3 rounded-lg">
                <p class="font-bold text-slate-200">${char.name}</p>
                <div class="flex flex-wrap gap-2 mt-2">
                    ${char.keywords.map(kw => `<span class="text-sm px-2 py-0.5 rounded-full bg-slate-700 ${getKeywordColor(kw)}">${kw}</span>`).join('')}
                </div>
                <div class="flex gap-2 mt-2">
                    <input type="text" data-char-id="${char.id}" class="keyword-input flex-grow text-sm bg-slate-700 border border-slate-600 rounded-md px-2 py-1 focus:outline-none focus:ring-1 focus:ring-amber-400" placeholder="性格丝线 (回车添加)" />
                </div>
            </div>
        `).join('');
        renderDraggables();
    }
    
    function renderPlots() {
        const list = document.getElementById('plots-list');
        list.innerHTML = state.plots.map(plot => `
            <div class="bg-slate-900/50 p-2 rounded-lg text-slate-300 text-sm">
                ${plot.description}
            </div>
        `).join('');
        renderDraggables();
    }

    function renderDraggables() {
        const sources = document.getElementById('draggable-sources');
        sources.innerHTML = `
            <h4 class="text-center font-serif text-slate-400 mb-2">可用的丝线</h4>
            <div class="flex flex-wrap justify-center gap-4">
                ${state.plots.map(p => `
                    <div draggable="true" class="draggable-item p-2 bg-slate-700 rounded-lg cursor-grab active:cursor-grabbing hover:bg-slate-600" data-type="plot" data-item='${JSON.stringify(p)}'>
                        <span class="text-amber-300">情:</span> ${p.description}
                    </div>
                `).join('')}
                ${state.characters.map(c => `
                    <div draggable="true" class="draggable-item p-2 bg-slate-700 rounded-lg cursor-grab active:cursor-grabbing hover:bg-slate-600" data-type="character" data-item='${JSON.stringify(c)}'>
                        <span class="text-cyan-300">角:</span> ${c.name}
                    </div>
                `).join('')}
            </div>
        `;
        addDragAndDropListeners();
    }

    // Initial renders
    renderCharacters();
    renderPlots();
    updateShuttleView();

    // --- Event Listeners ---
    document.getElementById('add-char-form').addEventListener('submit', e => {
        e.preventDefault();
        const input = document.getElementById('char-name-input');
        if (input.value.trim()) {
            state.characters.push({ id: Date.now(), name: input.value.trim(), keywords: [] });
            input.value = '';
            renderCharacters();
        }
    });

    document.getElementById('add-plot-form').addEventListener('submit', e => {
        e.preventDefault();
        const input = document.getElementById('plot-desc-input');
        if (input.value.trim()) {
            state.plots.push({ id: Date.now(), description: input.value.trim() });
            input.value = '';
            renderPlots();
        }
    });

    document.getElementById('characters-list').addEventListener('keydown', e => {
        if (e.key === 'Enter' && e.target.classList.contains('keyword-input')) {
            e.preventDefault();
            const charId = parseInt(e.target.dataset.charId);
            const keyword = e.target.value.trim();
            if (keyword) {
                const char = state.characters.find(c => c.id === charId);
                if (char) {
                    char.keywords.push(keyword);
                    e.target.value = '';
                    renderCharacters();
                }
            }
        }
    });

    function addDragAndDropListeners() {
        const draggables = document.querySelectorAll('.draggable-item');
        const shuttle = document.getElementById('droppable-shuttle');

        draggables.forEach(draggable => {
            draggable.addEventListener('dragstart', (e) => {
                e.dataTransfer.setData('application/json', e.target.dataset.item);
                e.dataTransfer.setData('text/plain', e.target.dataset.type);
                setTimeout(() => e.target.classList.add('opacity-50'), 0);
            });
            draggable.addEventListener('dragend', (e) => {
                 e.target.classList.remove('opacity-50');
            });
        });

        shuttle.addEventListener('dragover', (e) => {
            e.preventDefault();
            shuttle.classList.replace('border-slate-600', 'border-amber-400');
            shuttle.classList.add('bg-amber-400/10');
        });
        shuttle.addEventListener('dragleave', (e) => {
            shuttle.classList.replace('border-amber-400', 'border-slate-600');
            shuttle.classList.remove('bg-amber-400/10');
        });
        shuttle.addEventListener('drop', (e) => {
            e.preventDefault();
            shuttle.classList.replace('border-amber-400', 'border-slate-600');
            shuttle.classList.remove('bg-amber-400/10');
            
            const type = e.dataTransfer.getData('text/plain');
            const item = JSON.parse(e.dataTransfer.getData('application/json'));

            if (type === 'plot') {
                shuttleContent.plot = item;
            } else if (type === 'character') {
                if (!shuttleContent.chars.some(c => c.id === item.id)) {
                     shuttleContent.chars.push(item);
                }
            }
            updateShuttleView();
        });
    }

    document.getElementById('weave-button').addEventListener('click', async () => {
         if (!shuttleContent.plot || shuttleContent.chars.length === 0) {
            // A simple modal can be implemented here instead of alert
            alert("请将至少一个情节和一位角色放入梭子中。");
            return;
        }

        const button = document.getElementById('weave-button');
        button.disabled = true;
        button.innerHTML = `<div class="w-5 h-5 border-2 border-slate-900 border-t-transparent rounded-full animate-spin"></div>织造中...`;

        const charDesc = shuttleContent.chars.map(c => `${c.name} (${c.keywords.join(', ')})`).join('; ');
        const prompt = `
            请基于以下设定，创作一段富有想象力的故事：
            ### 经线 (世界框架)
            - **时代:** ${state.warp.era.name} (${state.warp.era.description})
            - **世界:** ${state.warp.world.name} (${state.warp.world.description})
            - **故事风格/纹理:** ${state.warp.style.name}
            ### 纬线 (当前情节)
            - **事件:** ${shuttleContent.plot.description}
            ### 丝线 (出场角色)
            - **角色:** ${charDesc}
            请以生动、符合所选风格的文笔，编织出接下来发生的故事。`;

        try {
            let chatHistory = [{ role: "user", parts: [{ text: prompt }] }];
            const payload = { contents: chatHistory };
            const apiKey = ""; 
            const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!response.ok) throw new Error(`API call failed with status: ${response.status}`);
            
            const result = await response.json();
            
            if (result.candidates && result.candidates[0]?.content?.parts?.[0]) {
                state.storyText += "\n\n" + result.candidates[0].content.parts[0].text;
            } else {
                throw new Error("未能从API获取有效的故事内容。");
            }

        } catch (error) {
            console.error("生成失败:", error);
            state.storyText += `\n\n// 生成时发生错误: ${error.message}`;
        } finally {
            state.stage = 'result';
            render();
        }
    });
}


function renderResult() {
    const baseHue = Math.abs(state.warp.style.name.split('').reduce((acc, char) => char.charCodeAt(0) + ((acc << 5) - acc), 0)) % 360;

    const resultHTML = `
        <div class="min-h-screen w-full text-slate-200 flex flex-col items-center p-6 sm:p-8 lg:p-12 animate-fade-in">
            <h1 class="text-4xl font-serif text-amber-300 mb-4">叙事织锦</h1>
            <p class="text-slate-400 mb-8">这是你独一无二的故事纹理</p>
            
            <div class="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div class="bg-slate-800/50 p-6 rounded-lg border border-slate-700">
                    <h2 class="text-2xl font-serif mb-4 flex items-center gap-2">${ICONS.TEXTURE('class="w-6 h-6"')}故事纹理</h2>
                    <div class="w-full aspect-video rounded-lg overflow-hidden border border-slate-700 bg-slate-900 flex items-center justify-center">
                         <svg width="100%" height="100%" viewBox="0 0 400 200">
                            <defs>
                                <filter id="turbulence">
                                    <feTurbulence type="fractalNoise" baseFrequency="${(state.storyText.length % 100) * 0.0001 + 0.02}" numOctaves="3" result="noise" />
                                    <feDiffuseLighting in="noise" lighting-color="hsl(${baseHue}, 90%, 70%)" surfaceScale="2">
                                        <feDistantLight azimuth="45" elevation="60" />
                                    </feDiffuseLighting>
                                </filter>
                            </defs>
                            <rect width="100%" height="100%" fill="hsl(${baseHue}, 40%, 20%)" />
                            <rect width="100%" height="100%" filter="url(#turbulence)" opacity="0.4" />
                        </svg>
                    </div>
                    <p class="text-xs text-slate-500 mt-2 text-center">这幅织锦的纹理由你的故事风格和内容独家生成。</p>
                </div>

                <div class="bg-slate-800/50 p-6 rounded-lg border border-slate-700 flex flex-col">
                    <h2 class="text-2xl font-serif mb-4">故事卷轴</h2>
                    <div id="story-text-area" class="flex-grow bg-slate-900/70 p-4 rounded-md overflow-y-auto max-h-[400px] whitespace-pre-wrap font-serif leading-relaxed no-scrollbar">${state.storyText.trim()}</div>
                </div>
            </div>

            <div class="mt-12 flex flex-wrap justify-center gap-4">
                 <button id="copy-button" class="px-6 py-3 bg-slate-700 rounded-lg hover:bg-slate-600 transition-colors">复制故事文本</button>
                 <button id="continue-button" class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors">返回织机继续创作</button>
                 <button id="reset-button" class="px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-900 font-bold rounded-lg hover:shadow-lg hover:shadow-amber-500/20 transition-all">开启新的织造</button>
            </div>
        </div>
    `;
    app.innerHTML = resultHTML;

    // Event listeners
    document.getElementById('copy-button').addEventListener('click', () => {
        navigator.clipboard.writeText(document.getElementById('story-text-area').innerText)
            .then(() => alert('故事已复制到剪贴板！'))
            .catch(err => console.error('复制失败', err));
    });

    document.getElementById('continue-button').addEventListener('click', () => {
        state.stage = 'weaving';
        render();
    });

    document.getElementById('reset-button').addEventListener('click', () => {
        // Reset state
        Object.assign(state, {
            stage: 'setup',
            warp: { era: null, world: null, style: null },
            characters: [],
            plots: [],
            storyText: "",
        });
        render();
    });
}


// --- 初始化应用 ---
// 首次加载时调用主渲染函数
render();

