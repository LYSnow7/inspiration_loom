// --- 全局状态管理 ---
// 用一个对象来管理整个应用的状态，替代 React 的 useState
const state = {
    stage: 'startup', // 当前阶段: 'startup', 'intro', 'setup', 'weaving', 'result'
    activeSpindle: null, // 当前激活的纺锤: 'character', 'background', 'plot', 'style'
    warp: { era: null, world: null, style: null }, // 经线 (故事框架)
    characters: [], // 角色列表
    plots: [], // 情节列表
    storyText: "", // 生成的故事文本
};

// --- DOM 节点 ---
const app = document.getElementById('app');

// --- SVG 图标 ---
// 将 React 组件转换为返回 SVG 字符串的函数
const ICONS = {
    SPINDLE: (props) => `<svg ${props} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" xmlns="http://www.w3.org/2000/svg"><path d="M12 2L15 5L12 8L9 5L12 2Z" stroke-linejoin="round"/><path d="M12 22L15 19L12 16L9 19L12 22Z" stroke-linejoin="round"/><path d="M5 15L2 12L5 9" stroke-linejoin="round"/><path d="M19 15L22 12L19 9" stroke-linejoin="round"/><path d="M12 8V16" /><path d="M15 5C17.5 7.5 17.5 16.5 15 19" /><path d="M9 5C6.5 7.5 6.5 16.5 9 19" /></svg>`,
    SHUTTLE: (props) => `<svg ${props} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2 32C2 32 12 4 32 4C52 4 62 32 62 32C62 32 52 60 32 60C12 60 2 32 2 32Z" stroke="currentColor" stroke-width="3" /><circle cx="32" cy="32" r="8" fill="currentColor" /></svg>`,
    THREAD: (props) => `<svg ${props} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 3C12 3 6 4.5 6 9C6 13.5 12 15 12 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M12 15C12 15 18 16.5 18 21C18 25.5 12 27 12 27" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" opacity="0.6"/><path d="M12 15C12 15 6 16.5 6 21C6 25.5 12 27 12 27" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" opacity="0.6"/><path d="M12 3C12 3 18 4.5 18 9C18 13.5 12 15 12 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
    TEXTURE: (props) => `<svg ${props} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" xmlns="http://www.w3.org/2000/svg"><path d="M3 5.2C3 5.2 4.2 4 6 4C7.8 4 9 5.2 9 5.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 12C3 12 4.2 10.8 6 10.8C7.8 10.8 9 12 9 12" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 18.8C3 18.8 4.2 17.6 6 17.6C7.8 17.6 9 18.8 9 18.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 5.2C15 5.2 16.2 4 18 4C19.8 4 21 5.2 21 5.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 12C15 12 16.2 10.8 18 10.8C19.8 10.8 21 12 21 12" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 18.8C15 18.8 16.2 17.6 18 17.6C19.8 17.6 21 18.8 21 18.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
};

// --- 数据 (已更新) ---
const WARP_OPTIONS = {
    era: [
        { name: "远古洪荒", icon: "🦖", description: "巨兽漫步，神话初生" },
        { name: "奇幻中世纪", icon: "🏰", description: "骑士与魔法，龙与传说" },
        { name: "武侠江湖", icon: "🗡️", description: "刀光剑影，快意恩仇" },
        { name: "蒸汽朋克", icon: "⚙️", description: "齿轮与奥秘，工业的轰鸣" },
        { name: "现代都市", icon: "🏢", description: "车水马龙，霓虹下的罪与爱" },
        { name: "赛博纪元", icon: "🌃", description: "霓虹与义体，高科技低生活" },
        { name: "末日废土", icon: "☢️", description: "文明的余烬，生存的挣扎" },
        { name: "星际未来", icon: "🚀", description: "深空探索，文明的碰撞" },
    ],
    world: [
        { name: "失落的古城", icon: "🏛️", description: "被遗忘的文明遗迹" },
        { name: "无尽的沙漠", icon: "🏜️", description: "烈日与流沙下的秘密" },
        { name: "浮空的岛屿", icon: "🏝️", description: "云海之上的奇迹国度" },
        { name: "幽深的森林", icon: "🌳", description: "古老树木间的精灵低语" },
        { name: "深海王国", icon: "🐠", description: "珊瑚与宫殿，遗忘的旋律" },
        { name: "云顶天宫", icon: "☁️", description: "仙雾缭绕，众神的居所" },
        { name: "机械都市", icon: "🤖", description: "精准与冰冷，秩序的堡垒" },
        { name: "繁华的都市", icon: "🏙️", description: "钢铁丛林中的万千故事" },
    ],
    style: [
        { name: "悬疑", icon: "❓", color: "from-indigo-400 to-slate-700" },
        { name: "浪漫", icon: "❤️", color: "from-rose-400 to-red-500" },
        { name: "史诗", icon: "⚔️", color: "from-amber-400 to-orange-600" },
        { name: "治愈", icon: "✨", color: "from-emerald-300 to-teal-500" },
        { name: "科幻", icon: "👩‍🚀", color: "from-sky-400 to-indigo-600" },
        { name: "喜剧", icon: "😂", color: "from-yellow-300 to-green-400" },
        { name: "哲理", icon: "🧠", color: "from-slate-400 to-gray-500" },
        { name: "恐怖", icon: "👻", color: "from-gray-700 to-black" },
    ],
};

const KEYWORD_COLORS = [ 'text-red-400', 'text-blue-400', 'text-green-400', 'text-yellow-400', 'text-purple-400', 'text-pink-400', 'text-indigo-400', 'text-teal-400', 'text-orange-400' ];
const getKeywordColor = (str) => {
    let hash = 0;
    for (let i = 0; i < str.length; i++) { hash = str.charCodeAt(i) + ((hash << 5) - hash); }
    return KEYWORD_COLORS[Math.abs(hash) % KEYWORD_COLORS.length];
};

// --- 渲染函数 ---

/**
 * 启动动画函数 - 同步编织动画
 */
function renderStartupAnimation() {
    const startupHTML = `
        <div id="startup-container" class="fixed inset-0 flex flex-col justify-center items-center overflow-hidden" style="background: #0a0a0a;">
            <!-- 微光背景 -->
            <div class="ambient-light"></div>

            <!-- 织物纹理叠加层 -->
            <div class="fabric-overlay"></div>

            <!-- 背景飘动丝线 -->
            <div class="floating-threads"></div>

            <!-- 文字区域 - 中央偏上 -->
            <div class="text-fabric">
                <div class="logo">灵感织机</div>
                <div class="subtitle">Inspiration Loom</div>
                <div class="slogan">编织属于你的叙事纹理</div>
            </div>

            <!-- 编织区域 - 下方 -->
            <div class="weaving-area">
                <div class="warp-threads"></div>
                <div class="spindles"></div>
            </div>
        </div>
    `;

    app.innerHTML = startupHTML;

    // 启动同步编织动画
    const animation = new SynchronizedWeavingAnimation();

    // 6. 完成后过渡到主界面 (6s)
    setTimeout(() => {
        const container = document.getElementById('startup-container');
        if (container) {
            container.style.animation = 'fadeOut 1s ease-out forwards';
        }
        setTimeout(() => {
            state.stage = 'intro';
            render();
        }, 1000);
    }, 6000);
}

/**
 * 同步编织动画类
 */
class SynchronizedWeavingAnimation {
    constructor() {
        this.container = document.querySelector('#startup-container');
        this.warpContainer = document.querySelector('.warp-threads');
        this.spindleContainer = document.querySelector('.spindles');
        this.textFabric = document.querySelector('.text-fabric');
        this.fabricOverlay = document.querySelector('.fabric-overlay');
        this.floatingContainer = document.querySelector('.floating-threads');

        this.init();
    }

    init() {
        // 立即创建背景飘动丝线
        this.createFloatingThreads();
        // 延迟开始同步动画
        setTimeout(() => this.startSynchronizedWeaving(), 1500);
    }

    // 创建背景飘动丝线
    createFloatingThreads() {
        for (let i = 0; i < 25; i++) {
            const thread = document.createElement('div');
            thread.className = 'floating-thread';
            thread.style.left = Math.random() * 100 + '%';
            thread.style.top = Math.random() * 100 + '%';
            thread.style.animationDelay = Math.random() * 3 + 's';
            thread.style.animationDuration = (4 + Math.random() * 2) + 's';
            this.floatingContainer.appendChild(thread);
        }
    }

    // 同步编织动画：文字和编织过程一起出现
    startSynchronizedWeaving() {
        // 1. 文字开始浮现
        this.textFabric.style.animation = 'textWeaveSync 3s ease-out forwards';

        // 2. 同时开始经线生长
        this.createWarpThreads();

        // 3. 稍后开始纺锤和光点
        setTimeout(() => this.createSpindlesAndParticles(), 800);

        // 4. 织物纹理最后出现
        setTimeout(() => {
            this.fabricOverlay.style.animation = 'fabricRevealSync 2s ease-out forwards';
        }, 2500);

        // 5. 最终光效
        setTimeout(() => this.addFinalGlow(), 3500);
    }

    // 创建经线
    createWarpThreads() {
        const warpCount = 12;
        const spacing = 45;
        const startX = (600 - spacing * (warpCount - 1)) / 2;

        for (let i = 0; i < warpCount; i++) {
            const warp = document.createElement('div');
            warp.className = 'warp-thread';
            warp.style.left = `${startX + i * spacing}px`;
            warp.style.animationDelay = `${i * 0.1}s`;
            warp.style.animation = 'warpGrowSync 2s ease-out forwards';

            this.warpContainer.appendChild(warp);
        }
    }

    // 创建纺锤和光点粒子
    createSpindlesAndParticles() {
        const spindlePositions = [120, 220, 320, 420];
        const threadColors = ['#FF6B6B', '#4ECDC4', '#FFD93D', '#6BCF7F'];

        spindlePositions.forEach((pos, index) => {
            // 创建光点粒子效果
            this.createLightParticles(pos, threadColors[index]);

            setTimeout(() => {
                // 创建纺锤
                const spindle = document.createElement('div');
                spindle.className = 'spindle';
                spindle.style.left = `${pos}px`;
                spindle.style.animation = 'fadeInSync 1s ease-out forwards';
                this.spindleContainer.appendChild(spindle);

                // 创建缠绕的丝线
                for (let i = 0; i < 4; i++) {
                    const thread = document.createElement('div');
                    thread.className = 'thread';
                    thread.style.background = threadColors[index];
                    thread.style.left = `${pos}px`;
                    thread.style.bottom = `${i * 6}px`;
                    thread.style.transformOrigin = `${2 + Math.random() * 2}px bottom`;
                    thread.style.animationDelay = `${i * 0.2}s`;
                    thread.style.animation = 'threadWindSync 1.5s ease-out forwards';
                    thread.style.boxShadow = `0 0 4px ${threadColors[index]}`;

                    this.spindleContainer.appendChild(thread);
                }
            }, index * 150);
        });
    }

    // 创建光点粒子效果
    createLightParticles(targetPos, color) {
        const particleCount = 6;

        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('div');
            particle.className = 'light-particle';
            particle.style.background = `radial-gradient(circle, ${color}, transparent)`;
            particle.style.boxShadow = `0 0 6px ${color}`;

            // 随机起始位置（从边缘）
            const side = Math.floor(Math.random() * 4);
            let startX, startY;

            switch(side) {
                case 0: startX = Math.random() * window.innerWidth; startY = 0; break;
                case 1: startX = window.innerWidth; startY = Math.random() * window.innerHeight; break;
                case 2: startX = Math.random() * window.innerWidth; startY = window.innerHeight; break;
                case 3: startX = 0; startY = Math.random() * window.innerHeight; break;
            }

            particle.style.left = `${startX}px`;
            particle.style.top = `${startY}px`;
            this.container.appendChild(particle);

            // 动画到目标位置
            setTimeout(() => {
                const weavingArea = document.querySelector('.weaving-area');
                const rect = weavingArea.getBoundingClientRect();

                particle.style.transition = 'all 1.5s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
                particle.style.left = `${rect.left + targetPos}px`;
                particle.style.top = `${rect.bottom - 40}px`;
                particle.style.opacity = '1';

                setTimeout(() => {
                    particle.style.animation = 'particleTravelSync 0.6s ease-out forwards';
                }, 1200);

                setTimeout(() => particle.remove(), 2000);
            }, i * 100);
        }
    }

    // 添加最终光效
    addFinalGlow() {
        const logo = document.querySelector('.logo');
        if (logo) {
            logo.style.filter = 'drop-shadow(0 0 20px rgba(255,255,255,0.4))';

            // 微妙的脉冲效果
            setInterval(() => {
                logo.style.textShadow = `
                    0 0 25px rgba(255,255,255,${0.3 + Math.random() * 0.2}),
                    0 0 50px rgba(255,215,0,${0.1 + Math.random() * 0.1})
                `;
            }, 2000);
        }
    }
}



/**
 * 主渲染函数，根据 state.stage 决定显示哪个界面
 */
function render() {
    // 清空主容器
    app.innerHTML = '';
    // 根据当前阶段渲染对应内容
    switch (state.stage) {
        case 'startup':
            renderStartupAnimation();
            break;
        case 'intro':
            renderIntro();
            break;
        case 'setup':
            renderSetup();
            break;
        case 'weaving':
            renderWeavingArea();
            break;
        case 'result':
            renderResult();
            break;
    }
}

function renderIntro() {
    // 动画HTML，已移除文字圈
    const introHTML = `
        <div id="intro-container" class="fixed inset-0 bg-slate-900 flex flex-col justify-center items-center transition-opacity duration-1000 opacity-100">
            <div class="relative w-80 h-80 flex justify-center items-center">
                <div id="loom-icon" class="transition-all duration-1000 opacity-0 scale-90">
                    <div class="w-64 h-64 border-4 border-amber-300 rounded-lg flex flex-col justify-between p-4 relative">
                       ${Array(7).fill(0).map((_, i) => `<div class="absolute h-full w-px bg-amber-200 opacity-50 top-0" style="left: ${(i+1)*12.5}%"></div>`).join('')}
                       <div class="w-full h-1 bg-amber-400 rounded-full"></div>
                         <p class="text-center text-amber-100 text-3xl font-serif mt-10">灵感织机</p>
                       <div class="w-full h-1 bg-amber-400 rounded-full"></div>
                    </div>
                </div>
            </div>
            <h1 id="slogan" class="mt-12 text-2xl font-serif text-slate-200 transition-opacity duration-1000 opacity-0">
                编织属于你的叙事纹理
            </h1>
        </div>
    `;
    app.innerHTML = introHTML;

    // 新的简化版动画逻辑
    setTimeout(() => {
        const loomIcon = document.getElementById('loom-icon');
        const slogan = document.getElementById('slogan');

        if (loomIcon && slogan) {
            // 让织机图标和口号淡入并放大
            loomIcon.classList.replace('opacity-0', 'opacity-100');
            loomIcon.classList.replace('scale-90', 'scale-100');
            slogan.classList.replace('opacity-0', 'opacity-100');
        }
    }, 500); // 延迟500毫秒后开始动画

    // 设置一个定时器，在4秒后过渡到下一个阶段
    setTimeout(() => {
        const introContainer = document.getElementById('intro-container');
        if (introContainer) {
            introContainer.classList.replace('opacity-100', 'opacity-0');
        }
        // 在淡出动画结束后，渲染设置界面
        setTimeout(() => {
            state.stage = 'setup';
            render();
        }, 1000); // 等待淡出动画完成
    }, 4000); // 动画总时长为4秒
}


function renderSetup() {
    // 四大核心纺锤定义
    const spindles = [
        {
            id: 'character',
            name: '角色纺锤',
            icon: '👤',
            description: '塑造故事的灵魂人物',
            color: 'from-cyan-400 to-blue-500',
            bgColor: 'bg-cyan-500/10',
            borderColor: 'border-cyan-400'
        },
        {
            id: 'background',
            name: '背景纺锤',
            icon: '🌍',
            description: '构建故事的世界舞台',
            color: 'from-green-400 to-emerald-500',
            bgColor: 'bg-green-500/10',
            borderColor: 'border-green-400'
        },
        {
            id: 'plot',
            name: '情节纺锤',
            icon: '📖',
            description: '编织故事的核心脉络',
            color: 'from-purple-400 to-violet-500',
            bgColor: 'bg-purple-500/10',
            borderColor: 'border-purple-400'
        },
        {
            id: 'style',
            name: '风格纺锤',
            icon: '🎨',
            description: '定义故事的表达质感',
            color: 'from-amber-400 to-orange-500',
            bgColor: 'bg-amber-500/10',
            borderColor: 'border-amber-400'
        }
    ];

    const setupHTML = `
        <div class="min-h-screen w-full text-slate-200 flex flex-col items-center p-6">
            <!-- 标题区域 -->
            <div class="text-center mb-12 animate-fade-in">
                <h1 class="text-5xl font-serif text-amber-300 mb-4">灵感纺锤架</h1>
                <p class="text-xl text-slate-400">选择一个纺锤开始创作你的故事</p>
            </div>

            <!-- 纺锤架主体 -->
            <div class="relative w-full max-w-6xl">
                <!-- 纺锤架背景装饰 -->
                <div class="absolute inset-0 opacity-10">
                    <svg width="100%" height="100%" viewBox="0 0 800 800">
                        <!-- 纺锤架框架 -->
                        <rect x="50" y="50" width="700" height="700" fill="none" stroke="#fbbf24" stroke-width="2" rx="20"/>
                        <!-- 横梁 -->
                        <line x1="50" y1="250" x2="750" y2="250" stroke="#fbbf24" stroke-width="1"/>
                        <line x1="50" y1="550" x2="750" y2="550" stroke="#fbbf24" stroke-width="1"/>
                        <!-- 竖梁 -->
                        <line x1="250" y1="50" x2="250" y2="750" stroke="#fbbf24" stroke-width="1"/>
                        <line x1="550" y1="50" x2="550" y2="750" stroke="#fbbf24" stroke-width="1"/>
                    </svg>
                </div>

                <!-- 四个纺锤 -->
                <div class="relative grid grid-cols-2 gap-16 p-12" style="min-height: 800px;">
                    ${spindles.map(spindle => `
                        <div class="spindle-container ${state.activeSpindle === spindle.id ? 'active' : ''}"
                             data-spindle="${spindle.id}">
                            <!-- 纺锤主体 -->
                            <div class="spindle-main relative bg-slate-800/70 backdrop-blur-sm rounded-2xl border-2 border-slate-700 p-6 cursor-pointer transition-all duration-500 hover:scale-105 hover:shadow-2xl hover:shadow-${spindle.color.split('-')[1]}-500/20">
                                <!-- 纺锤图标和标题 -->
                                <div class="text-center mb-4">
                                    <div class="text-6xl mb-3">${spindle.icon}</div>
                                    <h3 class="text-2xl font-serif text-slate-200 mb-2">${spindle.name}</h3>
                                    <p class="text-sm text-slate-400">${spindle.description}</p>
                                </div>

                                <!-- 纺锤状态指示器 -->
                                <div class="flex justify-center">
                                    <div class="w-16 h-2 bg-slate-700 rounded-full overflow-hidden">
                                        <div class="h-full bg-gradient-to-r ${spindle.color} transition-all duration-300 ${getSpindleProgress(spindle.id)}"></div>
                                    </div>
                                </div>
                            </div>

                            <!-- 展开的输入卡片 - 使用模态框方式 -->
                            <div class="spindle-card fixed left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 w-11/12 max-w-lg max-h-[80vh] overflow-y-auto bg-slate-800/95 backdrop-blur-sm rounded-xl border-2 border-amber-400 p-6 opacity-0 scale-95 transition-all duration-500 pointer-events-none z-50 shadow-2xl">
                                <div class="flex justify-between items-center mb-4">
                                    <h4 class="text-xl font-serif text-amber-300">${spindle.name}</h4>
                                    <button class="close-card text-slate-400 hover:text-white text-2xl font-bold">&times;</button>
                                </div>
                                ${renderSpindleCard(spindle)}
                            </div>

                            <!-- 遮罩层 -->
                            <div class="card-overlay fixed inset-0 bg-black/50 opacity-0 pointer-events-none transition-opacity duration-300 z-40"></div>
                        </div>
                    `).join('')}
                </div>
            </div>

            <!-- 底部操作区域 -->
            <div class="mt-12 flex flex-col items-center space-y-4">
                <div class="flex space-x-2">
                    ${spindles.map(spindle => `
                        <div class="w-3 h-3 rounded-full transition-colors duration-300 ${getSpindleProgress(spindle.id) ? 'bg-amber-400' : 'bg-slate-600'}"></div>
                    `).join('')}
                </div>
                <button id="continue-to-weaving" class="px-8 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-900 font-bold text-lg rounded-lg shadow-lg hover:shadow-amber-500/30 transition-all duration-300 ${isReadyToWeave() ? '' : 'opacity-50 cursor-not-allowed'}" ${isReadyToWeave() ? '' : 'disabled'}>
                    进入织造工坊
                </button>
            </div>
        </div>
    `;

    app.innerHTML = setupHTML;
    addSpindleEventListeners();
}

// 纺锤架辅助函数
function getSpindleProgress(spindleId) {
    switch (spindleId) {
        case 'character':
            return state.characters.length > 0 ? 'w-full' : 'w-0';
        case 'background':
            return (state.warp.era && state.warp.world) ? 'w-full' : 'w-0';
        case 'plot':
            return state.plots.length > 0 ? 'w-full' : 'w-0';
        case 'style':
            return state.warp.style ? 'w-full' : 'w-0';
        default:
            return 'w-0';
    }
}

function isReadyToWeave() {
    return state.characters.length > 0 &&
           state.plots.length > 0 &&
           state.warp.era &&
           state.warp.world &&
           state.warp.style;
}

function getCardPosition(spindleId) {
    // 根据纺锤位置智能选择卡片展开方向
    switch (spindleId) {
        case 'character':
            // 左上角纺锤，向右下展开
            return 'top-full left-0 right-0 mt-4';
        case 'background':
            // 右上角纺锤，向左下展开
            return 'top-full left-0 right-0 mt-4';
        case 'plot':
            // 左下角纺锤，向右上展开
            return 'bottom-full left-0 right-0 mb-4';
        case 'style':
            // 右下角纺锤，向左上展开
            return 'bottom-full left-0 right-0 mb-4';
        default:
            return 'top-full left-0 right-0 mt-4';
    }
}

function renderSpindleCard(spindle) {
    switch (spindle.id) {
        case 'character':
            return `
                <form id="add-char-form" class="mb-4">
                    <div class="flex gap-2">
                        <input type="text" id="char-name-input" placeholder="角色名称"
                               class="flex-grow bg-slate-900 border border-slate-600 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-400" />
                        <button type="submit" class="bg-cyan-500 text-white font-bold rounded-md px-4 py-2 hover:bg-cyan-400 transition-colors">
                            添加
                        </button>
                    </div>
                </form>
                <div id="characters-list" class="space-y-2 max-h-40 overflow-y-auto">
                    ${state.characters.map(char => `
                        <div class="bg-slate-900/50 p-3 rounded-lg">
                            <p class="font-bold text-slate-200">${char.name}</p>
                            <div class="flex flex-wrap gap-1 mt-2">
                                ${char.keywords.map(kw => `<span class="text-xs px-2 py-1 rounded-full bg-slate-700 ${getKeywordColor(kw)}">${kw}</span>`).join('')}
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;

        case 'background':
            return `
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm text-slate-400 mb-2">时代设定</label>
                        <div class="grid grid-cols-2 gap-2">
                            ${WARP_OPTIONS.era.slice(0, 4).map(era => `
                                <button class="era-option p-2 bg-slate-900 border border-slate-600 rounded-md hover:border-green-400 transition-colors ${state.warp.era?.name === era.name ? 'border-green-400 bg-green-500/10' : ''}"
                                        data-era='${JSON.stringify(era)}'>
                                    <span class="text-lg">${era.icon}</span>
                                    <span class="text-xs block">${era.name}</span>
                                </button>
                            `).join('')}
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm text-slate-400 mb-2">世界舞台</label>
                        <div class="grid grid-cols-2 gap-2">
                            ${WARP_OPTIONS.world.slice(0, 4).map(world => `
                                <button class="world-option p-2 bg-slate-900 border border-slate-600 rounded-md hover:border-green-400 transition-colors ${state.warp.world?.name === world.name ? 'border-green-400 bg-green-500/10' : ''}"
                                        data-world='${JSON.stringify(world)}'>
                                    <span class="text-lg">${world.icon}</span>
                                    <span class="text-xs block">${world.name}</span>
                                </button>
                            `).join('')}
                        </div>
                    </div>
                </div>
            `;

        case 'plot':
            return `
                <form id="add-plot-form" class="mb-4">
                    <div class="flex gap-2">
                        <input type="text" id="plot-desc-input" placeholder="情节描述"
                               class="flex-grow bg-slate-900 border border-slate-600 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
                        <button type="submit" class="bg-purple-500 text-white font-bold rounded-md px-4 py-2 hover:bg-purple-400 transition-colors">
                            添加
                        </button>
                    </div>
                </form>
                <div id="plots-list" class="space-y-2 max-h-40 overflow-y-auto">
                    ${state.plots.map(plot => `
                        <div class="bg-slate-900/50 p-2 rounded-lg text-slate-300 text-sm">
                            ${plot.description}
                        </div>
                    `).join('')}
                </div>
            `;

        case 'style':
            return `
                <div class="grid grid-cols-2 gap-2">
                    ${WARP_OPTIONS.style.map(style => `
                        <button class="style-option p-3 bg-slate-900 border border-slate-600 rounded-md hover:border-amber-400 transition-colors ${state.warp.style?.name === style.name ? 'border-amber-400 bg-amber-500/10' : ''}"
                                data-style='${JSON.stringify(style)}'>
                            <span class="text-2xl block mb-1">${style.icon}</span>
                            <span class="text-sm">${style.name}</span>
                        </button>
                    `).join('')}
                </div>
            `;

        default:
            return '<p class="text-slate-400">选择一个纺锤开始创作</p>';
    }
}

function addSpindleEventListeners() {
    // 纺锤点击事件
    document.querySelectorAll('.spindle-container').forEach(container => {
        const spindleMain = container.querySelector('.spindle-main');
        const closeBtn = container.querySelector('.close-card');
        const overlay = container.querySelector('.card-overlay');
        const spindleId = container.dataset.spindle;

        spindleMain.addEventListener('click', () => {
            // 关闭其他激活的纺锤
            document.querySelectorAll('.spindle-container').forEach(c => {
                c.classList.remove('active');
            });

            // 激活当前纺锤
            container.classList.add('active');
            state.activeSpindle = spindleId;
        });

        // 关闭按钮事件
        if (closeBtn) {
            closeBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                container.classList.remove('active');
                state.activeSpindle = null;
            });
        }

        // 遮罩层点击关闭
        if (overlay) {
            overlay.addEventListener('click', () => {
                container.classList.remove('active');
                state.activeSpindle = null;
            });
        }
    });

    // 角色表单事件
    const charForm = document.getElementById('add-char-form');
    if (charForm) {
        charForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const input = document.getElementById('char-name-input');
            if (input.value.trim()) {
                state.characters.push({
                    id: Date.now(),
                    name: input.value.trim(),
                    keywords: []
                });
                input.value = '';
                render();
            }
        });
    }

    // 情节表单事件
    const plotForm = document.getElementById('add-plot-form');
    if (plotForm) {
        plotForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const input = document.getElementById('plot-desc-input');
            if (input.value.trim()) {
                state.plots.push({
                    id: Date.now(),
                    description: input.value.trim()
                });
                input.value = '';
                render();
            }
        });
    }

    // 时代选择事件
    document.querySelectorAll('.era-option').forEach(button => {
        button.addEventListener('click', () => {
            const era = JSON.parse(button.dataset.era);
            state.warp.era = era;
            render();
        });
    });

    // 世界选择事件
    document.querySelectorAll('.world-option').forEach(button => {
        button.addEventListener('click', () => {
            const world = JSON.parse(button.dataset.world);
            state.warp.world = world;
            render();
        });
    });

    // 风格选择事件
    document.querySelectorAll('.style-option').forEach(button => {
        button.addEventListener('click', () => {
            const style = JSON.parse(button.dataset.style);
            state.warp.style = style;
            render();
        });
    });

    // 进入织造工坊按钮
    const continueBtn = document.getElementById('continue-to-weaving');
    if (continueBtn && !continueBtn.disabled) {
        continueBtn.addEventListener('click', () => {
            state.stage = 'weaving';
            state.activeSpindle = null;
            render();
        });
    }
}


// 更多渲染函数和逻辑...
function renderWeavingArea() {
    let shuttleContent = { plot: null, chars: [] };

    // Function to re-render the shuttle area
    function updateShuttleView() {
        const shuttleArea = document.getElementById('shuttle-area');
        if (shuttleArea) {
            shuttleArea.innerHTML = `
                <p class="text-slate-400 text-sm mb-1">将情节与角色拖入梭中</p>
                ${shuttleContent.plot ? `<p class="text-amber-300 text-xs truncate">情节: ${shuttleContent.plot.description}</p>` : ''}
                ${shuttleContent.chars.length > 0 ? `<p class="text-cyan-300 text-xs truncate">角色: ${shuttleContent.chars.map(c => c.name).join(', ')}</p>` : ''}
            `;
            const shuttleIcon = document.getElementById('shuttle-icon-main');
            if (shuttleIcon) {
                if (shuttleContent.plot) {
                    shuttleIcon.classList.add('text-amber-400');
                } else {
                    shuttleIcon.classList.remove('text-amber-400');
                }
            }
        }
    }
    
    const weavingHTML = `
        <div class="flex flex-col md:flex-row h-screen p-4 md:p-6 gap-6 text-slate-200">
            <!-- Left Panel: Spindles -->
            <div class="w-full md:w-96 bg-slate-800/70 backdrop-blur-sm p-4 rounded-lg border border-slate-700 flex-shrink-0 flex flex-col gap-6 overflow-y-auto no-scrollbar">
                <div>
                    <h3 class="text-xl font-serif text-amber-300 flex items-center gap-2 mb-3">${ICONS.SPINDLE('class="w-6 h-6"')} 角色纺锤</h3>
                    <form id="add-char-form" class="flex gap-2">
                        <input type="text" id="char-name-input" placeholder="新角色名" class="flex-grow bg-slate-900 border border-slate-600 rounded-md px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-amber-400" />
                        <button type="submit" class="bg-amber-500 text-slate-900 font-bold rounded-md px-3 py-1.5 hover:bg-amber-400 transition-colors">添加</button>
                    </form>
                    <div id="characters-list" class="mt-4 space-y-3"></div>
                </div>
                <div>
                    <h3 class="text-xl font-serif text-amber-300 flex items-center gap-2 mb-3">${ICONS.THREAD('class="w-6 h-6"')} 情节纺锤</h3>
                    <form id="add-plot-form" class="flex gap-2">
                        <input type="text" id="plot-desc-input" placeholder="新情节纬线" class="flex-grow bg-slate-900 border border-slate-600 rounded-md px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-amber-400" />
                        <button type="submit" class="bg-amber-500 text-slate-900 font-bold rounded-md px-3 py-1.5 hover:bg-amber-400 transition-colors">添加</button>
                    </form>
                    <div id="plots-list" class="mt-4 space-y-2"></div>
                </div>
            </div>

            <!-- Right Panel: Weaving Area -->
            <div class="flex-grow flex flex-col items-center justify-between p-6 bg-slate-900/50 rounded-lg border border-slate-700">
                <div class="relative w-full h-24 mb-6">
                     <div class="absolute inset-0 flex justify-around items-center">
                        ${Array(9).fill(0).map((_, i) => `<div class="w-px h-full bg-gradient-to-b from-transparent via-amber-300/50 to-transparent"></div>`).join('')}
                    </div>
                    <div class="absolute inset-0 flex flex-col justify-between">
                       <div class="h-1 rounded-full bg-gradient-to-r ${state.warp.style.color}"></div>
                       <div class="text-center py-2">
                           <p class="font-serif text-slate-300">${state.warp.era.name} | ${state.warp.world.name}</p>
                           <p class="text-xs text-slate-400">故事纹理: ${state.warp.style.name}</p>
                       </div>
                       <div class="h-1 rounded-full bg-gradient-to-r ${state.warp.style.color}"></div>
                    </div>
                </div>

                <div id="draggable-sources" class="w-full mb-6"></div>
                
                <div id="droppable-shuttle" class="relative flex flex-col items-center justify-center p-6 border-2 border-dashed rounded-2xl transition-all duration-300 border-slate-600">
                    ${ICONS.SHUTTLE('id="shuttle-icon-main" class="w-32 h-32 text-slate-500 transition-colors duration-300"')}
                    <div id="shuttle-area" class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 text-center pointer-events-none">
                        <!-- shuttle content here -->
                    </div>
                </div>

                <button id="weave-button" class="mt-8 w-full max-w-sm flex items-center justify-center gap-3 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-900 font-bold text-xl py-4 rounded-lg shadow-lg hover:shadow-amber-500/30 transition-all duration-300">
                    ${ICONS.SHUTTLE('class="w-7 h-7"')} 引梭织布
                </button>
            </div>
        </div>
    `;
    app.innerHTML = weavingHTML;
    
    // --- Update UI functions ---
    function renderCharacters() {
        const list = document.getElementById('characters-list');
        list.innerHTML = state.characters.map(char => `
            <div class="bg-slate-900/50 p-3 rounded-lg">
                <p class="font-bold text-slate-200">${char.name}</p>
                <div class="flex flex-wrap gap-2 mt-2">
                    ${char.keywords.map(kw => `<span class="text-sm px-2 py-0.5 rounded-full bg-slate-700 ${getKeywordColor(kw)}">${kw}</span>`).join('')}
                </div>
                <div class="flex gap-2 mt-2">
                    <input type="text" data-char-id="${char.id}" class="keyword-input flex-grow text-sm bg-slate-700 border border-slate-600 rounded-md px-2 py-1 focus:outline-none focus:ring-1 focus:ring-amber-400" placeholder="性格丝线 (回车添加)" />
                </div>
            </div>
        `).join('');
        renderDraggables();
    }
    
    function renderPlots() {
        const list = document.getElementById('plots-list');
        list.innerHTML = state.plots.map(plot => `
            <div class="bg-slate-900/50 p-2 rounded-lg text-slate-300 text-sm">
                ${plot.description}
            </div>
        `).join('');
        renderDraggables();
    }

    function renderDraggables() {
        const sources = document.getElementById('draggable-sources');
        sources.innerHTML = `
            <h4 class="text-center font-serif text-slate-400 mb-2">可用的丝线</h4>
            <div class="flex flex-wrap justify-center gap-4">
                ${state.plots.map(p => `
                    <div draggable="true" class="draggable-item p-2 bg-slate-700 rounded-lg cursor-grab active:cursor-grabbing hover:bg-slate-600" data-type="plot" data-item='${JSON.stringify(p)}'>
                        <span class="text-amber-300">情:</span> ${p.description}
                    </div>
                `).join('')}
                ${state.characters.map(c => `
                    <div draggable="true" class="draggable-item p-2 bg-slate-700 rounded-lg cursor-grab active:cursor-grabbing hover:bg-slate-600" data-type="character" data-item='${JSON.stringify(c)}'>
                        <span class="text-cyan-300">角:</span> ${c.name}
                    </div>
                `).join('')}
            </div>
        `;
        addDragAndDropListeners();
    }

    // Initial renders
    renderCharacters();
    renderPlots();
    updateShuttleView();

    // --- Event Listeners ---
    document.getElementById('add-char-form').addEventListener('submit', e => {
        e.preventDefault();
        const input = document.getElementById('char-name-input');
        if (input.value.trim()) {
            state.characters.push({ id: Date.now(), name: input.value.trim(), keywords: [] });
            input.value = '';
            renderCharacters();
        }
    });

    document.getElementById('add-plot-form').addEventListener('submit', e => {
        e.preventDefault();
        const input = document.getElementById('plot-desc-input');
        if (input.value.trim()) {
            state.plots.push({ id: Date.now(), description: input.value.trim() });
            input.value = '';
            renderPlots();
        }
    });

    document.getElementById('characters-list').addEventListener('keydown', e => {
        if (e.key === 'Enter' && e.target.classList.contains('keyword-input')) {
            e.preventDefault();
            const charId = parseInt(e.target.dataset.charId);
            const keyword = e.target.value.trim();
            if (keyword) {
                const char = state.characters.find(c => c.id === charId);
                if (char) {
                    char.keywords.push(keyword);
                    e.target.value = '';
                    renderCharacters();
                }
            }
        }
    });

    function addDragAndDropListeners() {
        const draggables = document.querySelectorAll('.draggable-item');
        const shuttle = document.getElementById('droppable-shuttle');

        draggables.forEach(draggable => {
            draggable.addEventListener('dragstart', (e) => {
                e.dataTransfer.setData('application/json', e.target.dataset.item);
                e.dataTransfer.setData('text/plain', e.target.dataset.type);
                setTimeout(() => e.target.classList.add('opacity-50'), 0);
            });
            draggable.addEventListener('dragend', (e) => {
                 e.target.classList.remove('opacity-50');
            });
        });

        shuttle.addEventListener('dragover', (e) => {
            e.preventDefault();
            shuttle.classList.replace('border-slate-600', 'border-amber-400');
            shuttle.classList.add('bg-amber-400/10');
        });
        shuttle.addEventListener('dragleave', (e) => {
            shuttle.classList.replace('border-amber-400', 'border-slate-600');
            shuttle.classList.remove('bg-amber-400/10');
        });
        shuttle.addEventListener('drop', (e) => {
            e.preventDefault();
            shuttle.classList.replace('border-amber-400', 'border-slate-600');
            shuttle.classList.remove('bg-amber-400/10');
            
            const type = e.dataTransfer.getData('text/plain');
            const item = JSON.parse(e.dataTransfer.getData('application/json'));

            if (type === 'plot') {
                shuttleContent.plot = item;
            } else if (type === 'character') {
                if (!shuttleContent.chars.some(c => c.id === item.id)) {
                     shuttleContent.chars.push(item);
                }
            }
            updateShuttleView();
        });
    }

    document.getElementById('weave-button').addEventListener('click', async () => {
         if (!shuttleContent.plot || shuttleContent.chars.length === 0) {
            // A simple modal can be implemented here instead of alert
            alert("请将至少一个情节和一位角色放入梭子中。");
            return;
        }

        const button = document.getElementById('weave-button');
        button.disabled = true;
        button.innerHTML = `<div class="w-5 h-5 border-2 border-slate-900 border-t-transparent rounded-full animate-spin"></div>织造中...`;

        const charDesc = shuttleContent.chars.map(c => `${c.name} (${c.keywords.join(', ')})`).join('; ');
        const prompt = `
            请基于以下设定，创作一段富有想象力的故事：
            ### 经线 (世界框架)
            - **时代:** ${state.warp.era.name} (${state.warp.era.description})
            - **世界:** ${state.warp.world.name} (${state.warp.world.description})
            - **故事风格/纹理:** ${state.warp.style.name}
            ### 纬线 (当前情节)
            - **事件:** ${shuttleContent.plot.description}
            ### 丝线 (出场角色)
            - **角色:** ${charDesc}
            请以生动、符合所选风格的文笔，编织出接下来发生的故事。`;

        try {
            let chatHistory = [{ role: "user", parts: [{ text: prompt }] }];
            const payload = { contents: chatHistory };
            const apiKey = ""; 
            const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!response.ok) throw new Error(`API call failed with status: ${response.status}`);
            
            const result = await response.json();
            
            if (result.candidates && result.candidates[0]?.content?.parts?.[0]) {
                state.storyText += "\n\n" + result.candidates[0].content.parts[0].text;
            } else {
                throw new Error("未能从API获取有效的故事内容。");
            }

        } catch (error) {
            console.error("生成失败:", error);
            state.storyText += `\n\n// 生成时发生错误: ${error.message}`;
        } finally {
            // 改为调用新的织锦台渲染函数
            renderWeavingResult(state.storyText);
        }
    });
}

/**
 * 故事织锦台 - 文字织出效果
 */
function renderWeavingResult(storyText) {
    const baseHue = Math.abs(state.warp.style.name.split('').reduce((acc, char) => char.charCodeAt(0) + ((acc << 5) - acc), 0)) % 360;

    const weavingHTML = `
        <div class="min-h-screen w-full text-slate-200 flex">
            <!-- 左侧织机控制台 -->
            <div class="w-1/3 bg-slate-800/70 backdrop-blur-sm p-6 border-r border-slate-700 flex flex-col">
                <div class="text-center mb-8">
                    <h1 class="text-3xl font-serif text-amber-300 mb-2">故事织锦台</h1>
                    <p class="text-slate-400 text-sm">正在编织您的叙事纹理...</p>
                </div>

                <!-- 织机状态 -->
                <div class="bg-slate-900/50 rounded-lg p-4 mb-6">
                    <h3 class="text-lg font-serif text-amber-300 mb-3 flex items-center gap-2">
                        ${ICONS.TEXTURE('class="w-5 h-5"')} 织造信息
                    </h3>
                    <div class="space-y-2 text-sm">
                        <div class="flex justify-between">
                            <span class="text-slate-400">时代经线:</span>
                            <span class="text-slate-200">${state.warp.era?.name || '未设定'}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-slate-400">世界经线:</span>
                            <span class="text-slate-200">${state.warp.world?.name || '未设定'}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-slate-400">故事纹理:</span>
                            <span class="text-slate-200">${state.warp.style?.name || '未设定'}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-slate-400">角色数量:</span>
                            <span class="text-slate-200">${state.characters.length}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-slate-400">情节数量:</span>
                            <span class="text-slate-200">${state.plots.length}</span>
                        </div>
                    </div>
                </div>

                <!-- 织造进度 -->
                <div class="bg-slate-900/50 rounded-lg p-4 mb-6">
                    <h3 class="text-lg font-serif text-amber-300 mb-3">织造进度</h3>
                    <div class="space-y-3">
                        <div class="flex items-center gap-3">
                            <div class="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                            <span class="text-sm text-slate-300">经线布设完成</span>
                        </div>
                        <div class="flex items-center gap-3">
                            <div class="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                            <span class="text-sm text-slate-300">纬线交织中...</span>
                        </div>
                        <div class="flex items-center gap-3">
                            <div class="w-3 h-3 bg-amber-400 rounded-full animate-pulse" id="weaving-indicator"></div>
                            <span class="text-sm text-slate-300" id="weaving-status">故事文字织出中...</span>
                        </div>
                    </div>
                </div>

                <!-- 操作按钮 -->
                <div class="mt-auto space-y-3">
                    <button id="pause-weaving" class="w-full px-4 py-2 bg-slate-700 text-slate-200 rounded-lg hover:bg-slate-600 transition-colors">
                        暂停织造
                    </button>
                    <button id="continue-weaving" class="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors">
                        返回织机
                    </button>
                    <button id="reset-weaving" class="w-full px-4 py-2 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-900 font-bold rounded-lg hover:shadow-lg hover:shadow-amber-500/20 transition-all">
                        重新开始
                    </button>
                </div>
            </div>

            <!-- 右侧故事织锦区域 -->
            <div class="flex-1 relative overflow-hidden">
                <!-- 莎草纸背景 -->
                <div class="absolute inset-0 papyrus-background"></div>

                <!-- 装饰性丝线 -->
                <div class="absolute inset-0 pointer-events-none">
                    ${Array(15).fill(0).map((_, i) => `
                        <div class="weaving-thread" style="
                            left: ${Math.random() * 100}%;
                            top: ${Math.random() * 100}%;
                            animation-delay: ${Math.random() * 2}s;
                            animation-duration: ${4 + Math.random() * 2}s;
                        "></div>
                    `).join('')}
                </div>

                <!-- 故事文本区域 -->
                <div class="relative z-10 h-full p-8 overflow-y-auto">
                    <div class="max-w-4xl mx-auto">
                        <div class="text-center mb-8">
                            <h2 class="text-4xl font-serif text-amber-800 mb-2 drop-shadow-lg">叙事织锦</h2>
                            <div class="w-32 h-1 bg-gradient-to-r from-transparent via-amber-600 to-transparent mx-auto"></div>
                        </div>

                        <!-- 动态文字容器 -->
                        <div id="story-weaving-container" class="story-text-container font-serif text-lg leading-relaxed text-slate-800">
                            <!-- 文字将在这里逐步显现 -->
                        </div>

                        <!-- 织造光标 -->
                        <span id="weaving-cursor" class="weaving-cursor">|</span>
                    </div>
                </div>
            </div>
        </div>
    `;

    app.innerHTML = weavingHTML;

    // 开始文字织出动画
    startTextWeavingAnimation(storyText);

    // 添加事件监听器
    addWeavingEventListeners();
}

function startTextWeavingAnimation(text) {
    const container = document.getElementById('story-weaving-container');
    const cursor = document.getElementById('weaving-cursor');
    const weavingIndicator = document.getElementById('weaving-indicator');
    const weavingStatus = document.getElementById('weaving-status');

    if (!container || !text) return;

    // 清空容器
    container.innerHTML = '';

    // 将文本按段落分割
    const paragraphs = text.trim().split('\n\n').filter(p => p.trim());
    let currentParagraphIndex = 0;
    let currentCharIndex = 0;
    let isPaused = false;

    // 创建段落元素
    paragraphs.forEach((_, index) => {
        const p = document.createElement('p');
        p.className = 'mb-6 opacity-0 transform translate-y-4 transition-all duration-500';
        p.id = `paragraph-${index}`;
        container.appendChild(p);
    });

    function typeNextCharacter() {
        if (isPaused || currentParagraphIndex >= paragraphs.length) {
            // 织造完成
            cursor.style.display = 'none';
            weavingIndicator.className = 'w-3 h-3 bg-green-400 rounded-full';
            weavingStatus.textContent = '故事织造完成！';
            return;
        }

        const currentParagraph = paragraphs[currentParagraphIndex];
        const paragraphElement = document.getElementById(`paragraph-${currentParagraphIndex}`);

        if (currentCharIndex === 0) {
            // 显示新段落
            paragraphElement.classList.remove('opacity-0', 'translate-y-4');
            paragraphElement.classList.add('opacity-100', 'translate-y-0');
        }

        if (currentCharIndex < currentParagraph.length) {
            // 添加下一个字符
            const char = currentParagraph[currentCharIndex];
            paragraphElement.textContent += char;
            currentCharIndex++;

            // 移动光标到当前位置
            paragraphElement.appendChild(cursor);

            // 根据字符类型调整速度
            let delay = 50; // 默认速度
            if (char === '。' || char === '！' || char === '？') {
                delay = 300; // 句号后停顿
            } else if (char === '，' || char === '；') {
                delay = 150; // 逗号后短暂停顿
            } else if (char === ' ') {
                delay = 30; // 空格快速
            }

            setTimeout(typeNextCharacter, delay);
        } else {
            // 当前段落完成，移到下一段落
            currentParagraphIndex++;
            currentCharIndex = 0;
            setTimeout(typeNextCharacter, 500); // 段落间停顿
        }
    }

    // 开始织造动画
    setTimeout(typeNextCharacter, 1000);

    // 暂停/继续功能
    window.pauseWeaving = () => {
        isPaused = true;
        weavingStatus.textContent = '织造已暂停';
    };

    window.resumeWeaving = () => {
        isPaused = false;
        weavingStatus.textContent = '故事文字织出中...';
        typeNextCharacter();
    };
}

function addWeavingEventListeners() {
    const pauseBtn = document.getElementById('pause-weaving');
    const continueBtn = document.getElementById('continue-weaving');
    const resetBtn = document.getElementById('reset-weaving');

    let isPaused = false;

    pauseBtn.addEventListener('click', () => {
        if (isPaused) {
            window.resumeWeaving();
            pauseBtn.textContent = '暂停织造';
            isPaused = false;
        } else {
            window.pauseWeaving();
            pauseBtn.textContent = '继续织造';
            isPaused = true;
        }
    });

    continueBtn.addEventListener('click', () => {
        state.stage = 'weaving';
        render();
    });

    resetBtn.addEventListener('click', () => {
        Object.assign(state, {
            stage: 'setup',
            activeSpindle: null,
            warp: { era: null, world: null, style: null },
            characters: [],
            plots: [],
            storyText: "",
        });
        render();
    });
}


function renderResult() {
    const baseHue = Math.abs(state.warp.style.name.split('').reduce((acc, char) => char.charCodeAt(0) + ((acc << 5) - acc), 0)) % 360;

    const resultHTML = `
        <div class="min-h-screen w-full text-slate-200 flex flex-col items-center p-6 sm:p-8 lg:p-12 animate-fade-in">
            <h1 class="text-4xl font-serif text-amber-300 mb-4">叙事织锦</h1>
            <p class="text-slate-400 mb-8">这是你独一无二的故事纹理</p>
            
            <div class="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div class="bg-slate-800/50 p-6 rounded-lg border border-slate-700">
                    <h2 class="text-2xl font-serif mb-4 flex items-center gap-2">${ICONS.TEXTURE('class="w-6 h-6"')}故事纹理</h2>
                    <div class="w-full aspect-video rounded-lg overflow-hidden border border-slate-700 bg-slate-900 flex items-center justify-center">
                         <svg width="100%" height="100%" viewBox="0 0 400 200">
                            <defs>
                                <filter id="turbulence">
                                    <feTurbulence type="fractalNoise" baseFrequency="${(state.storyText.length % 100) * 0.0001 + 0.02}" numOctaves="3" result="noise" />
                                    <feDiffuseLighting in="noise" lighting-color="hsl(${baseHue}, 90%, 70%)" surfaceScale="2">
                                        <feDistantLight azimuth="45" elevation="60" />
                                    </feDiffuseLighting>
                                </filter>
                            </defs>
                            <rect width="100%" height="100%" fill="hsl(${baseHue}, 40%, 20%)" />
                            <rect width="100%" height="100%" filter="url(#turbulence)" opacity="0.4" />
                        </svg>
                    </div>
                    <p class="text-xs text-slate-500 mt-2 text-center">这幅织锦的纹理由你的故事风格和内容独家生成。</p>
                </div>

                <div class="bg-slate-800/50 p-6 rounded-lg border border-slate-700 flex flex-col">
                    <h2 class="text-2xl font-serif mb-4">故事卷轴</h2>
                    <div id="story-text-area" class="flex-grow bg-slate-900/70 p-4 rounded-md overflow-y-auto max-h-[400px] whitespace-pre-wrap font-serif leading-relaxed no-scrollbar">${state.storyText.trim()}</div>
                </div>
            </div>

            <div class="mt-12 flex flex-wrap justify-center gap-4">
                 <button id="copy-button" class="px-6 py-3 bg-slate-700 rounded-lg hover:bg-slate-600 transition-colors">复制故事文本</button>
                 <button id="continue-button" class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors">返回织机继续创作</button>
                 <button id="reset-button" class="px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-900 font-bold rounded-lg hover:shadow-lg hover:shadow-amber-500/20 transition-all">开启新的织造</button>
            </div>
        </div>
    `;
    app.innerHTML = resultHTML;

    // Event listeners
    document.getElementById('copy-button').addEventListener('click', () => {
        navigator.clipboard.writeText(document.getElementById('story-text-area').innerText)
            .then(() => alert('故事已复制到剪贴板！'))
            .catch(err => console.error('复制失败', err));
    });

    document.getElementById('continue-button').addEventListener('click', () => {
        state.stage = 'weaving';
        render();
    });

    document.getElementById('reset-button').addEventListener('click', () => {
        // Reset state
        Object.assign(state, {
            stage: 'setup',
            warp: { era: null, world: null, style: null },
            characters: [],
            plots: [],
            storyText: "",
        });
        render();
    });
}


// --- 初始化应用 ---
// 首次加载时调用主渲染函数
render();

