# 灵感织机 - CSS 文件结构说明

## 文件概览

项目的样式文件已经按功能模块进行了分离，以提高代码的可维护性和加载性能。

### 📁 CSS 文件结构

```
├── style.css              # 主样式文件
├── startup-animation.css   # 启动动画专用样式
└── CSS-README.md          # 本说明文件
```

## 📋 文件详细说明

### 1. `style.css` - 主样式文件
**用途**: 包含应用的核心样式和布局
**包含内容**:
- 基础样式和重置
- 滚动条样式
- 灵感纺锤架样式
- 故事织锦台样式
- 响应式设计
- 通用动画效果

**主要样式模块**:
- `.spindle-container` - 纺锤容器样式
- `.papyrus-background` - 莎草纸背景
- `.story-text-container` - 故事文本容器
- `.weaving-cursor` - 织造光标

### 2. `startup-animation.css` - 启动动画样式
**用途**: 专门处理启动动画的所有视觉效果
**包含内容**:
- 丝线交织动画
- 文字浮现效果
- 加载指示器
- 装饰性元素动画
- 性能优化设置

**主要动画**:
- `@keyframes threadAppear` - 经线出现动画
- `@keyframes threadWeave` - 纬线交织动画
- `@keyframes textWeaveIn` - 文字交织动画
- `@keyframes loadingPulse` - 加载点脉冲动画
- `@keyframes floatThread` - 浮动丝线动画

## 🔧 引入方式

在HTML文件中按以下顺序引入CSS文件：

```html
<!-- 主样式文件 -->
<link rel="stylesheet" href="style.css">
<!-- 启动动画样式 -->
<link rel="stylesheet" href="startup-animation.css">
```

## 📱 性能优化特性

### 启动动画CSS包含的优化：
1. **硬件加速**: 使用 `will-change` 属性
2. **响应式设计**: 移动端适配
3. **无障碍支持**: `prefers-reduced-motion` 媒体查询
4. **性能友好**: 避免重排和重绘的动画属性

### 分离的优势：
- **按需加载**: 可以选择性加载动画样式
- **缓存优化**: 启动动画样式可以单独缓存
- **维护性**: 动画相关样式集中管理
- **性能**: 减少主样式文件大小

## 🎨 自定义指南

### 修改启动动画：
编辑 `startup-animation.css` 文件中的相关样式：
- 调整动画时长: 修改 `animation-duration` 属性
- 改变颜色主题: 修改 `#fbbf24` 等颜色值
- 添加新动画: 创建新的 `@keyframes` 规则

### 修改主界面样式：
编辑 `style.css` 文件中的相关样式：
- 纺锤架布局: 修改 `.spindle-container` 相关样式
- 织锦台外观: 修改 `.papyrus-background` 等样式
- 响应式断点: 调整 `@media` 查询条件

## 🔄 版本历史

- **v1.1** - CSS文件分离
  - 将启动动画样式独立为单独文件
  - 添加性能优化和无障碍支持
  - 完善文档说明

- **v1.0** - 初始版本
  - 所有样式集中在单一CSS文件中

## 📞 技术支持

如需修改样式或添加新功能，请参考：
1. 本文档的自定义指南
2. CSS文件中的注释说明
3. 各测试页面的实现示例

---

*最后更新: 2024年6月*
