// --- 全局状态管理 ---
// 用一个对象来管理整个应用的状态，替代 React 的 useState
const state = {
    stage: 'intro', // 当前阶段: 'intro', 'setup', 'weaving', 'result'
    warp: { era: null, world: null, style: null }, // 经线 (故事框架)
    characters: [], // 角色列表
    plots: [], // 情节列表
    storyText: "", // 生成的故事文本
};

// --- DOM 节点 ---
const app = document.getElementById('app');

// --- SVG 图标 ---
// 将 React 组件转换为返回 SVG 字符串的函数
const ICONS = {
    SPINDLE: (props) => `<svg ${props} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" xmlns="http://www.w3.org/2000/svg"><path d="M12 2L15 5L12 8L9 5L12 2Z" stroke-linejoin="round"/><path d="M12 22L15 19L12 16L9 19L12 22Z" stroke-linejoin="round"/><path d="M5 15L2 12L5 9" stroke-linejoin="round"/><path d="M19 15L22 12L19 9" stroke-linejoin="round"/><path d="M12 8V16" /><path d="M15 5C17.5 7.5 17.5 16.5 15 19" /><path d="M9 5C6.5 7.5 6.5 16.5 9 19" /></svg>`,
    SHUTTLE: (props) => `<svg ${props} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2 32C2 32 12 4 32 4C52 4 62 32 62 32C62 32 52 60 32 60C12 60 2 32 2 32Z" stroke="currentColor" stroke-width="3" /><circle cx="32" cy="32" r="8" fill="currentColor" /></svg>`,
    THREAD: (props) => `<svg ${props} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 3C12 3 6 4.5 6 9C6 13.5 12 15 12 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M12 15C12 15 18 16.5 18 21C18 25.5 12 27 12 27" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" opacity="0.6"/><path d="M12 15C12 15 6 16.5 6 21C6 25.5 12 27 12 27" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" opacity="0.6"/><path d="M12 3C12 3 18 4.5 18 9C18 13.5 12 15 12 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
    TEXTURE: (props) => `<svg ${props} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" xmlns="http://www.w3.org/2000/svg"><path d="M3 5.2C3 5.2 4.2 4 6 4C7.8 4 9 5.2 9 5.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 12C3 12 4.2 10.8 6 10.8C7.8 10.8 9 12 9 12" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 18.8C3 18.8 4.2 17.6 6 17.6C7.8 17.6 9 18.8 9 18.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 5.2C15 5.2 16.2 4 18 4C19.8 4 21 5.2 21 5.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 12C15 12 16.2 10.8 18 10.8C19.8 10.8 21 12 21 12" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 18.8C15 18.8 16.2 17.6 18 17.6C19.8 17.6 21 18.8 21 18.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
};

// --- 数据 (已更新) ---
const WARP_OPTIONS = {
    era: [
        { name: "远古洪荒", icon: "🦖", description: "巨兽漫步，神话初生" },
        { name: "奇幻中世纪", icon: "🏰", description: "骑士与魔法，龙与传说" },
        { name: "武侠江湖", icon: "🗡️", description: "刀光剑影，快意恩仇" },
        { name: "蒸汽朋克", icon: "⚙️", description: "齿轮与奥秘，工业的轰鸣" },
        { name: "现代都市", icon: "🏢", description: "车水马龙，霓虹下的罪与爱" },
        { name: "赛博纪元", icon: "🌃", description: "霓虹与义体，高科技低生活" },
        { name: "末日废土", icon: "☢️", description: "文明的余烬，生存的挣扎" },
        { name: "星际未来", icon: "🚀", description: "深空探索，文明的碰撞" },
    ],
    world: [
        { name: "失落的古城", icon: "🏛️", description: "被遗忘的文明遗迹" },
        { name: "无尽的沙漠", icon: "🏜️", description: "烈日与流沙下的秘密" },
        { name: "浮空的岛屿", icon: "🏝️", description: "云海之上的奇迹国度" },
        { name: "幽深的森林", icon: "🌳", description: "古老树木间的精灵低语" },
        { name: "深海王国", icon: "🐠", description: "珊瑚与宫殿，遗忘的旋律" },
        { name: "云顶天宫", icon: "☁️", description: "仙雾缭绕，众神的居所" },
        { name: "机械都市", icon: "🤖", description: "精准与冰冷，秩序的堡垒" },
        { name: "繁华的都市", icon: "🏙️", description: "钢铁丛林中的万千故事" },
    ],
    style: [
        { name: "悬疑", icon: "❓", color: "from-indigo-400 to-slate-700" },
        { name: "浪漫", icon: "❤️", color: "from-rose-400 to-red-500" },
        { name: "史诗", icon: "⚔️", color: "from-amber-400 to-orange-600" },
        { name: "治愈", icon: "✨", color: "from-emerald-300 to-teal-500" },
        { name: "科幻", icon: "👩‍🚀", color: "from-sky-400 to-indigo-600" },
        { name: "喜剧", icon: "😂", color: "from-yellow-300 to-green-400" },
        { name: "哲理", icon: "🧠", color: "from-slate-400 to-gray-500" },
        { name: "恐怖", icon: "👻", color: "from-gray-700 to-black" },
    ],
};

const KEYWORD_COLORS = [ 'text-red-400', 'text-blue-400', 'text-green-400', 'text-yellow-400', 'text-purple-400', 'text-pink-400', 'text-indigo-400', 'text-teal-400', 'text-orange-400' ];
const getKeywordColor = (str) => {
    let hash = 0;
    for (let i = 0; i < str.length; i++) { hash = str.charCodeAt(i) + ((hash << 5) - hash); }
    return KEYWORD_COLORS[Math.abs(hash) % KEYWORD_COLORS.length];
};

// --- 渲染函数 ---

/**
 * 主渲染函数，根据 state.stage 决定显示哪个界面
 */
function render() {
    // 清空主容器
    app.innerHTML = '';
    // 根据当前阶段渲染对应内容
    switch (state.stage) {
        case 'intro':
            renderIntro();
            break;
        case 'setup':
            renderSetup();
            break;
        case 'weaving':
            renderWeavingArea();
            break;
        case 'result':
            renderResult();
            break;
    }
}

function renderIntro() {
    // 使用synchronized-weaving.html中的精美加载动画
    const introHTML = `
        <div id="intro-container" class="fixed inset-0 transition-opacity duration-1000 opacity-100">
            <style>
                .loom-container {
                    position: relative;
                    width: 100vw;
                    height: 100vh;
                    overflow: hidden;
                    background: #0f172a;
                }

                /* 微光背景 */
                .ambient-light {
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    width: 500px;
                    height: 500px;
                    background: radial-gradient(circle, rgba(255,255,255,0.05) 0%, transparent 70%);
                    transform: translate(-50%, -50%);
                    animation: breathe 4s ease-in-out infinite;
                }

                @keyframes breathe {
                    0%, 100% { transform: translate(-50%, -50%) scale(0.8); opacity: 0.3; }
                    50% { transform: translate(-50%, -50%) scale(1.2); opacity: 0.6; }
                }

                /* 背景飘动的丝线 */
                .floating-thread {
                    position: absolute;
                    width: 1px;
                    height: 30px;
                    background: linear-gradient(180deg, transparent, rgba(251,191,36,0.4), transparent);
                    opacity: 0.3;
                    animation: floatThread 6s ease-in-out infinite;
                    pointer-events: none;
                    z-index: 1;
                }

                @keyframes floatThread {
                    0%, 100% {
                        transform: translateY(0) rotate(0deg);
                        opacity: 0.2;
                    }
                    25% {
                        transform: translateY(-15px) rotate(45deg);
                        opacity: 0.5;
                    }
                    50% {
                        transform: translateY(-8px) rotate(90deg);
                        opacity: 0.7;
                    }
                    75% {
                        transform: translateY(-20px) rotate(135deg);
                        opacity: 0.4;
                    }
                }

                /* 文字区域 - 中央 */
                .text-fabric {
                    position: absolute;
                    top: 45%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    text-align: center;
                    opacity: 0;
                    z-index: 10;
                    background: rgba(15, 23, 42, 0.7);
                    padding: 40px 50px;
                    border-radius: 20px;
                    backdrop-filter: blur(15px);
                    border: 1px solid rgba(255,255,255,0.1);
                }

                .logo {
                    font-size: 64px;
                    font-weight: bold;
                    margin-bottom: 20px;
                    background: linear-gradient(45deg, #FFD700, #FF6B6B, #4ECDC4, #45B7D1);
                    background-size: 400% 400%;
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                    background-clip: text;
                    animation: gradientShift 3s ease-in-out infinite;
                    text-shadow: 0 0 20px rgba(255,255,255,0.3);
                }

                .subtitle {
                    font-size: 24px;
                    color: #bbb;
                    margin-bottom: 15px;
                    letter-spacing: 1px;
                }

                .slogan {
                    font-size: 18px;
                    color: #999;
                    font-weight: 300;
                    letter-spacing: 0.5px;
                }

                @keyframes gradientShift {
                    0%, 100% { background-position: 0% 50%; }
                    50% { background-position: 100% 50%; }
                }

                /* 编织区域 - 下方 */
                .weaving-area {
                    position: absolute;
                    bottom: 15%;
                    left: 50%;
                    transform: translateX(-50%);
                    width: 600px;
                    height: 200px;
                    z-index: 5;
                }

                /* 经线 */
                .warp-thread {
                    position: absolute;
                    width: 1px;
                    height: 0;
                    background: linear-gradient(to bottom, transparent, rgba(255,255,255,0.8), transparent);
                    top: 0;
                    transform: translateX(-50%);
                    opacity: 0;
                    box-shadow: 0 0 6px rgba(255,255,255,0.6);
                }

                /* 纺锤 */
                .spindle {
                    position: absolute;
                    bottom: 0;
                    width: 6px;
                    height: 40px;
                    background: linear-gradient(to bottom, #8B4513, #CD853F, #8B4513);
                    border-radius: 3px;
                    opacity: 0;
                    transform: translateX(-50%);
                }

                /* 丝线 */
                .thread {
                    position: absolute;
                    width: 1px;
                    height: 25px;
                    border-radius: 0.5px;
                    opacity: 0;
                    transform-origin: bottom center;
                }

                /* 光点粒子 */
                .light-particle {
                    position: absolute;
                    width: 3px;
                    height: 3px;
                    background: radial-gradient(circle, rgba(255,255,255,0.9), transparent);
                    border-radius: 50%;
                    opacity: 0;
                }

                /* 同步动画关键帧 */
                @keyframes warpGrowSync {
                    0% {
                        height: 0;
                        opacity: 0;
                    }
                    100% {
                        height: 180px;
                        opacity: 1;
                    }
                }

                @keyframes textWeaveSync {
                    0% {
                        opacity: 0;
                        transform: translate(-50%, -50%) scale(0.8);
                        filter: blur(10px);
                    }
                    30% {
                        opacity: 0.3;
                        transform: translate(-50%, -50%) scale(0.9);
                        filter: blur(5px);
                    }
                    60% {
                        opacity: 0.7;
                        transform: translate(-50%, -50%) scale(1.02);
                        filter: blur(2px);
                    }
                    100% {
                        opacity: 1;
                        transform: translate(-50%, -50%) scale(1);
                        filter: blur(0px);
                    }
                }

                @keyframes threadWindSync {
                    0% {
                        opacity: 0;
                        transform: rotate(0deg) scale(0);
                    }
                    50% {
                        opacity: 0.5;
                        transform: rotate(180deg) scale(0.7);
                    }
                    100% {
                        opacity: 0.9;
                        transform: rotate(360deg) scale(1);
                    }
                }

                @keyframes particleTravelSync {
                    0% {
                        opacity: 1;
                        transform: scale(1);
                    }
                    50% {
                        opacity: 0.9;
                        transform: scale(1.2);
                    }
                    90% {
                        opacity: 0.8;
                    }
                    100% {
                        opacity: 0;
                        transform: scale(0.3);
                    }
                }

                @keyframes fadeInSync {
                    0% { opacity: 0; transform: translateY(10px); }
                    100% { opacity: 1; transform: translateY(0); }
                }

                /* 织物纹理效果 */
                .fabric-overlay {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    opacity: 0;
                    background:
                        repeating-linear-gradient(
                            0deg,
                            transparent,
                            transparent 2px,
                            rgba(255,255,255,0.008) 2px,
                            rgba(255,255,255,0.008) 4px
                        ),
                        repeating-linear-gradient(
                            90deg,
                            transparent,
                            transparent 2px,
                            rgba(255,255,255,0.004) 2px,
                            rgba(255,255,255,0.004) 4px
                        );
                    pointer-events: none;
                }

                @keyframes fabricRevealSync {
                    0% { opacity: 0; }
                    100% { opacity: 1; }
                }
            </style>

            <div class="loom-container">
                <!-- 微光背景 -->
                <div class="ambient-light"></div>

                <!-- 织物纹理叠加层 -->
                <div class="fabric-overlay"></div>

                <!-- 背景飘动丝线 -->
                <div class="floating-threads"></div>

                <!-- 文字区域 -->
                <div class="text-fabric">
                    <div class="logo">灵感织机</div>
                    <div class="subtitle">Inspiration Loom</div>
                    <div class="slogan">编织属于你的叙事纹理</div>
                </div>

                <!-- 编织区域 -->
                <div class="weaving-area">
                    <div class="warp-threads"></div>
                    <div class="spindles"></div>
                </div>
            </div>
        </div>
    `;
    app.innerHTML = introHTML;

    // 启动同步编织动画
    const weavingAnimation = new SynchronizedWeavingAnimation();

    // 设置一个定时器，在5秒后过渡到下一个阶段
    setTimeout(() => {
        const introContainer = document.getElementById('intro-container');
        if (introContainer) {
            introContainer.classList.replace('opacity-100', 'opacity-0');
        }
        // 在淡出动画结束后，渲染设置界面
        setTimeout(() => {
            state.stage = 'setup';
            render();
        }, 1000); // 等待淡出动画完成
    }, 5000); // 动画总时长为5秒
}


function renderSetup(step = 0) {
    const steps = [
        { title: "第一步: 选择时代经线", category: "era", options: WARP_OPTIONS.era, prompt: "故事发生在哪个时代？" },
        { title: "第二步: 设定世界经线", category: "world", options: WARP_OPTIONS.world, prompt: "它的舞台在何处？" },
        { title: "第三步: 定义故事纹理", category: "style", options: WARP_OPTIONS.style, prompt: "你希望它呈现何种质感？" }
    ];
    
    if (step >= steps.length) {
        state.stage = 'weaving';
        render();
        return;
    }

    const currentStep = steps[step];
    const setupHTML = `
        <div class="min-h-screen w-full text-slate-200 flex flex-col justify-center items-center p-4">
            <div class="text-center w-full max-w-7xl animate-fade-in">
                <p class="text-amber-300 font-serif mb-2">${currentStep.title}</p>
                <h2 class="text-4xl font-serif mb-12">${currentStep.prompt}</h2>
                <div class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-4 md:gap-6">
                    ${currentStep.options.map(option => `
                        <div class="relative group flex justify-center">
                            <button class="setup-option aspect-square bg-slate-800/50 border border-slate-700 rounded-xl flex flex-col justify-center items-center p-4 hover:bg-slate-700 hover:border-amber-400 hover:scale-105 transition-all duration-300"
                                    data-category="${currentStep.category}" data-value='${JSON.stringify(option)}'>
                                <span class="text-5xl mb-2">${option.icon}</span>
                                <span class="font-serif text-lg text-center">${option.name}</span>
                            </button>
                            <div class="absolute bottom-full mb-2 w-max px-3 py-1.5 text-sm text-white bg-gray-800 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                                ${option.description || option.name}
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
            <div class="fixed bottom-8 flex space-x-4">
                ${steps.map((s, i) => `<div class="w-3 h-3 rounded-full transition-colors duration-300 ${step >= i ? 'bg-amber-400' : 'bg-slate-600'}"></div>`).join('')}
            </div>
        </div>
    `;
    app.innerHTML = setupHTML;
    
    // 添加事件监听器
    document.querySelectorAll('.setup-option').forEach(button => {
        button.addEventListener('click', (e) => {
            const target = e.currentTarget;
            const category = target.dataset.category;
            const value = JSON.parse(target.dataset.value);
            state.warp[category] = value;
            setTimeout(() => renderSetup(step + 1), 300);
        });
    });
}


// 更多渲染函数和逻辑...
function renderWeavingArea() {
    let shuttleContent = { plots: [], chars: [] };

    // Function to re-render the shuttle area
    function updateShuttleView() {
        const shuttleArea = document.getElementById('shuttle-area');
        if (shuttleArea) {
            if (shuttleContent.plots.length === 0 && shuttleContent.chars.length === 0) {
                shuttleArea.innerHTML = `
                    <div class="text-center">
                        <p class="text-slate-400 text-sm font-medium mb-2">梭子空闲中</p>
                        <p class="text-slate-500 text-xs">拖入情节和角色开始编织</p>
                    </div>
                `;
            } else {
                shuttleArea.innerHTML = `
                    <div class="space-y-2">
                        ${shuttleContent.plots.length > 0 ? `
                            <div class="bg-cyan-400/10 border border-cyan-400/30 rounded-lg p-2 backdrop-blur-sm">
                                <p class="text-cyan-300 text-xs font-medium mb-1 text-center">情节纬线</p>
                                <div class="flex flex-wrap justify-center gap-1 mb-1">
                                    ${shuttleContent.plots.map(plot => `
                                        <span class="text-cyan-200 text-xs bg-cyan-400/20 px-2 py-0.5 rounded-full">${plot.description}</span>
                                    `).join('')}
                                </div>
                            </div>
                        ` : ''}
                        ${shuttleContent.chars.length > 0 ? `
                            <div class="bg-amber-400/10 border border-amber-400/30 rounded-lg p-2 backdrop-blur-sm">
                                <p class="text-amber-300 text-xs font-medium mb-1 text-center">角色丝线</p>
                                <div class="flex flex-wrap justify-center gap-1">
                                    ${shuttleContent.chars.map(c => `<span class="text-amber-200 text-xs bg-amber-400/20 px-2 py-0.5 rounded-full">${c.name}</span>`).join('')}
                                </div>
                            </div>
                        ` : ''}
                    </div>
                `;
            }

            const shuttleIcon = document.getElementById('shuttle-icon-main');
            if (shuttleIcon) {
                if (shuttleContent.plots.length > 0 || shuttleContent.chars.length > 0) {
                    shuttleIcon.classList.add('text-amber-400');
                    shuttleIcon.classList.remove('text-slate-400');
                } else {
                    shuttleIcon.classList.remove('text-amber-400');
                    shuttleIcon.classList.add('text-slate-400');
                }
            }
        }
    }
    
    const weavingHTML = `
        <div class="flex flex-col lg:flex-row h-screen p-4 lg:p-6 gap-6 text-slate-200 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
            <!-- Left Panel: Spindles -->
            <div class="w-full lg:w-96 bg-gradient-to-b from-slate-800/80 to-slate-900/80 backdrop-blur-lg p-6 rounded-2xl border border-slate-600/50 shadow-2xl flex-shrink-0 flex flex-col gap-8 overflow-y-auto no-scrollbar">
                <!-- 角色纺锤区域 -->
                <div class="space-y-4">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="p-2 bg-gradient-to-br from-amber-400 to-orange-500 rounded-lg shadow-lg">
                            ${ICONS.SPINDLE('class="w-6 h-6 text-slate-900"')}
                        </div>
                        <h3 class="text-xl font-serif text-amber-300 font-bold">角色纺锤</h3>
                    </div>
                    <form id="add-char-form" class="relative">
                        <div class="flex gap-3">
                            <div class="flex-grow relative">
                                <input type="text" id="char-name-input" placeholder="新角色名"
                                    class="w-full bg-slate-900/70 border border-slate-600/50 rounded-xl px-4 py-3 text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400/50 focus:border-amber-400 transition-all duration-300 backdrop-blur-sm" />
                                <div class="absolute inset-0 bg-gradient-to-r from-amber-400/5 to-orange-400/5 rounded-xl pointer-events-none"></div>
                            </div>
                            <button type="submit" class="bg-gradient-to-r from-amber-500 to-orange-500 text-slate-900 font-bold rounded-xl px-6 py-3 hover:from-amber-400 hover:to-orange-400 transition-all duration-300 shadow-lg hover:shadow-amber-500/30 transform hover:scale-105">
                                添加
                            </button>
                        </div>
                    </form>
                    <div id="characters-list" class="space-y-3"></div>
                </div>

                <!-- 情节纺锤区域 -->
                <div class="space-y-4">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="p-2 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-lg shadow-lg">
                            ${ICONS.THREAD('class="w-6 h-6 text-slate-900"')}
                        </div>
                        <h3 class="text-xl font-serif text-cyan-300 font-bold">情节纺锤</h3>
                    </div>
                    <form id="add-plot-form" class="relative">
                        <div class="flex gap-3">
                            <div class="flex-grow relative">
                                <input type="text" id="plot-desc-input" placeholder="新情节纬线"
                                    class="w-full bg-slate-900/70 border border-slate-600/50 rounded-xl px-4 py-3 text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400 transition-all duration-300 backdrop-blur-sm" />
                                <div class="absolute inset-0 bg-gradient-to-r from-cyan-400/5 to-blue-400/5 rounded-xl pointer-events-none"></div>
                            </div>
                            <button type="submit" class="bg-gradient-to-r from-cyan-500 to-blue-500 text-slate-900 font-bold rounded-xl px-6 py-3 hover:from-cyan-400 hover:to-blue-400 transition-all duration-300 shadow-lg hover:shadow-cyan-500/30 transform hover:scale-105">
                                添加
                            </button>
                        </div>
                    </form>
                    <div id="plots-list" class="space-y-3"></div>
                </div>
            </div>

            <!-- Right Panel: Weaving Area -->
            <div class="flex-grow flex flex-col items-center justify-between p-8 bg-gradient-to-b from-slate-900/60 to-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-600/50 shadow-2xl">
                <!-- 经线框架显示 -->
                <div class="relative w-full h-32 mb-8 bg-gradient-to-r from-slate-800/50 to-slate-700/50 rounded-xl p-4 border border-slate-600/30 shadow-inner">
                     <div class="absolute inset-0 flex justify-around items-center px-4">
                        ${Array(9).fill(0).map((_, i) => `<div class="w-px h-full bg-gradient-to-b from-transparent via-amber-300/60 to-transparent shadow-sm"></div>`).join('')}
                    </div>
                    <div class="absolute inset-0 flex flex-col justify-between p-4">
                       <div class="h-2 rounded-full bg-gradient-to-r ${state.warp.style.color} shadow-lg"></div>
                       <div class="text-center py-2 bg-slate-900/30 rounded-lg backdrop-blur-sm">
                           <p class="font-serif text-slate-200 text-lg font-bold">${state.warp.era.name} | ${state.warp.world.name}</p>
                           <p class="text-sm text-slate-400 mt-1">故事纹理: <span class="text-amber-300">${state.warp.style.name}</span></p>
                       </div>
                       <div class="h-2 rounded-full bg-gradient-to-r ${state.warp.style.color} shadow-lg"></div>
                    </div>
                </div>

                <!-- 可用丝线区域 -->
                <div id="draggable-sources" class="w-full mb-8"></div>

                <!-- 梭子区域 -->
                <div id="droppable-shuttle" class="relative flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-3xl transition-all duration-500 border-slate-500/50 bg-gradient-to-br from-slate-800/30 to-slate-900/30 backdrop-blur-sm hover:border-amber-400/50 hover:bg-amber-400/5 group">
                    ${ICONS.SHUTTLE('id="shuttle-icon-main" class="w-40 h-40 text-slate-400 transition-all duration-500 group-hover:text-amber-400 group-hover:scale-105 drop-shadow-lg"')}
                    <div id="shuttle-area" class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-56 text-center pointer-events-none">
                        <!-- shuttle content here -->
                    </div>
                    <p class="mt-4 text-slate-500 text-sm font-medium group-hover:text-amber-400 transition-colors duration-300">将情节与角色拖入梭中开始编织</p>
                </div>

                <!-- 编织按钮 -->
                <button id="weave-button" class="mt-10 w-full max-w-md flex items-center justify-center gap-4 bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 text-slate-900 font-bold text-xl py-5 rounded-2xl shadow-2xl hover:shadow-amber-500/40 transition-all duration-300 transform hover:scale-105 hover:from-amber-400 hover:via-orange-400 hover:to-red-400 relative overflow-hidden group">
                    <div class="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    ${ICONS.SHUTTLE('class="w-8 h-8 relative z-10"')}
                    <span class="relative z-10">引梭织布</span>
                </button>
            </div>
        </div>
    `;
    app.innerHTML = weavingHTML;
    
    // --- Update UI functions ---
    function renderCharacters() {
        const list = document.getElementById('characters-list');
        list.innerHTML = state.characters.map(char => `
            <div class="bg-gradient-to-br from-slate-800/60 to-slate-900/60 backdrop-blur-sm p-4 rounded-xl border border-slate-600/30 shadow-lg hover:shadow-xl transition-all duration-300 hover:border-amber-400/30 group">
                <div class="flex items-center gap-3 mb-3">
                    <div class="w-3 h-3 bg-gradient-to-r from-amber-400 to-orange-500 rounded-full shadow-sm"></div>
                    <p class="font-bold text-slate-200 text-lg group-hover:text-amber-300 transition-colors">${char.name}</p>
                </div>
                <div class="flex flex-wrap gap-2 mb-3">
                    ${char.keywords.map(kw => `<span class="text-xs px-3 py-1 rounded-full bg-gradient-to-r from-slate-700 to-slate-600 ${getKeywordColor(kw)} border border-slate-500/30 shadow-sm hover:shadow-md transition-all duration-200 hover:scale-105">${kw}</span>`).join('')}
                </div>
                <div class="relative">
                    <input type="text" data-char-id="${char.id}" class="keyword-input w-full text-sm bg-slate-900/50 border border-slate-600/50 rounded-lg px-3 py-2 text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400/50 focus:border-amber-400 transition-all duration-300" placeholder="性格丝线 (回车添加)" />
                    <div class="absolute inset-0 bg-gradient-to-r from-amber-400/5 to-orange-400/5 rounded-lg pointer-events-none"></div>
                </div>
            </div>
        `).join('');
        renderDraggables();
    }
    
    function renderPlots() {
        const list = document.getElementById('plots-list');
        list.innerHTML = state.plots.map(plot => `
            <div class="bg-gradient-to-br from-slate-800/60 to-slate-900/60 backdrop-blur-sm p-4 rounded-xl border border-slate-600/30 shadow-lg hover:shadow-xl transition-all duration-300 hover:border-cyan-400/30 group">
                <div class="flex items-start gap-3">
                    <div class="w-3 h-3 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full shadow-sm mt-1 flex-shrink-0"></div>
                    <p class="text-slate-300 text-sm leading-relaxed group-hover:text-cyan-300 transition-colors">${plot.description}</p>
                </div>
            </div>
        `).join('');
        renderDraggables();
    }

    function renderDraggables() {
        const sources = document.getElementById('draggable-sources');
        sources.innerHTML = `
            <div class="text-center mb-6">
                <h4 class="font-serif text-slate-300 text-lg mb-2">可用的丝线</h4>
                <p class="text-slate-500 text-sm">拖拽下方元素到梭子中进行编织</p>
            </div>
            <div class="flex flex-wrap justify-center gap-3">
                ${state.plots.map(p => `
                    <div draggable="true" class="draggable-item group p-3 bg-gradient-to-br from-slate-700/80 to-slate-800/80 backdrop-blur-sm rounded-xl cursor-grab active:cursor-grabbing hover:from-slate-600/80 hover:to-slate-700/80 border border-slate-600/30 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 hover:border-cyan-400/50" data-type="plot" data-item='${JSON.stringify(p)}'>
                        <div class="flex items-center gap-2">
                            <div class="w-2 h-2 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full shadow-sm"></div>
                            <span class="text-cyan-300 font-medium text-sm">情节:</span>
                        </div>
                        <p class="text-slate-300 text-sm mt-1 group-hover:text-cyan-200 transition-colors">${p.description}</p>
                    </div>
                `).join('')}
                ${state.characters.map(c => `
                    <div draggable="true" class="draggable-item group p-3 bg-gradient-to-br from-slate-700/80 to-slate-800/80 backdrop-blur-sm rounded-xl cursor-grab active:cursor-grabbing hover:from-slate-600/80 hover:to-slate-700/80 border border-slate-600/30 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 hover:border-amber-400/50" data-type="character" data-item='${JSON.stringify(c)}'>
                        <div class="flex items-center gap-2">
                            <div class="w-2 h-2 bg-gradient-to-r from-amber-400 to-orange-500 rounded-full shadow-sm"></div>
                            <span class="text-amber-300 font-medium text-sm">角色:</span>
                        </div>
                        <p class="text-slate-300 text-sm mt-1 group-hover:text-amber-200 transition-colors">${c.name}</p>
                        ${c.keywords.length > 0 ? `<div class="flex flex-wrap gap-1 mt-2">${c.keywords.slice(0, 3).map(kw => `<span class="text-xs px-2 py-0.5 rounded-full bg-slate-600/50 text-slate-400">${kw}</span>`).join('')}${c.keywords.length > 3 ? '<span class="text-xs text-slate-500">...</span>' : ''}</div>` : ''}
                    </div>
                `).join('')}
            </div>
        `;
        addDragAndDropListeners();
    }

    // Initial renders
    renderCharacters();
    renderPlots();
    updateShuttleView();

    // --- Event Listeners ---
    document.getElementById('add-char-form').addEventListener('submit', e => {
        e.preventDefault();
        const input = document.getElementById('char-name-input');
        if (input.value.trim()) {
            state.characters.push({ id: Date.now(), name: input.value.trim(), keywords: [] });
            input.value = '';
            renderCharacters();
        }
    });

    document.getElementById('add-plot-form').addEventListener('submit', e => {
        e.preventDefault();
        const input = document.getElementById('plot-desc-input');
        if (input.value.trim()) {
            state.plots.push({ id: Date.now(), description: input.value.trim() });
            input.value = '';
            renderPlots();
        }
    });

    document.getElementById('characters-list').addEventListener('keydown', e => {
        if (e.key === 'Enter' && e.target.classList.contains('keyword-input')) {
            e.preventDefault();
            const charId = parseInt(e.target.dataset.charId);
            const keyword = e.target.value.trim();
            if (keyword) {
                const char = state.characters.find(c => c.id === charId);
                if (char) {
                    char.keywords.push(keyword);
                    e.target.value = '';
                    renderCharacters();
                }
            }
        }
    });

    function addDragAndDropListeners() {
        const draggables = document.querySelectorAll('.draggable-item');
        const shuttle = document.getElementById('droppable-shuttle');

        draggables.forEach(draggable => {
            draggable.addEventListener('dragstart', (e) => {
                e.dataTransfer.setData('application/json', e.target.dataset.item);
                e.dataTransfer.setData('text/plain', e.target.dataset.type);
                setTimeout(() => e.target.classList.add('opacity-50'), 0);
            });
            draggable.addEventListener('dragend', (e) => {
                 e.target.classList.remove('opacity-50');
            });
        });

        shuttle.addEventListener('dragover', (e) => {
            e.preventDefault();
            shuttle.classList.replace('border-slate-600', 'border-amber-400');
            shuttle.classList.add('bg-amber-400/10');
        });
        shuttle.addEventListener('dragleave', (e) => {
            shuttle.classList.replace('border-amber-400', 'border-slate-600');
            shuttle.classList.remove('bg-amber-400/10');
        });
        shuttle.addEventListener('drop', (e) => {
            e.preventDefault();
            shuttle.classList.replace('border-amber-400', 'border-slate-600');
            shuttle.classList.remove('bg-amber-400/10');
            
            const type = e.dataTransfer.getData('text/plain');
            const item = JSON.parse(e.dataTransfer.getData('application/json'));

            if (type === 'plot') {
                // 检查是否已存在相同ID的情节，避免重复添加
                if (!shuttleContent.plots.some(p => p.id === item.id)) {
                    shuttleContent.plots.push(item);
                }
            } else if (type === 'character') {
                if (!shuttleContent.chars.some(c => c.id === item.id)) {
                    shuttleContent.chars.push(item);
                }
            }
            updateShuttleView();
        });
    }

    document.getElementById('weave-button').addEventListener('click', async () => {
        if (shuttleContent.plots.length === 0 || shuttleContent.chars.length === 0) {
            // A simple modal can be implemented here instead of alert
            alert("请将至少一个情节和一位角色放入梭子中。");
            return;
        }

        const button = document.getElementById('weave-button');
        button.disabled = true;
        button.innerHTML = `<div class="w-5 h-5 border-2 border-slate-900 border-t-transparent rounded-full animate-spin"></div>织造中...`;

        const charDesc = shuttleContent.chars.map(c => `${c.name} (${c.keywords.join(', ')})`).join('; ');
        const plotDesc = shuttleContent.plots.map(p => p.description).join('；');
        const prompt = `
            请基于以下设定，创作一段富有想象力的故事：
            ### 经线 (世界框架)
            - **时代:** ${state.warp.era.name} (${state.warp.era.description})
            - **世界:** ${state.warp.world.name} (${state.warp.world.description})
            - **故事风格/纹理:** ${state.warp.style.name}
            ### 纬线 (当前情节)
            - **事件:** ${plotDesc}
            ### 丝线 (出场角色)
            - **角色:** ${charDesc}
            请以生动、符合所选风格的文笔，编织出接下来发生的故事。`;

        try {
            // 配置Gemini 2.5 Flash API
            const apiKey = "AIzaSyDsbMOApPK4NCJEl0JQ1S95Dajv-zL4XR4";
            const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;

            // 构建请求payload
            const payload = {
                contents: [{
                    role: "user",
                    parts: [{ text: prompt }]
                }],
                generationConfig: {
                    temperature: 0.8,
                    topK: 40,
                    topP: 0.95,
                    maxOutputTokens: 2048,
                },
                safetySettings: [
                    {
                        category: "HARM_CATEGORY_HARASSMENT",
                        threshold: "BLOCK_MEDIUM_AND_ABOVE"
                    },
                    {
                        category: "HARM_CATEGORY_HATE_SPEECH",
                        threshold: "BLOCK_MEDIUM_AND_ABOVE"
                    },
                    {
                        category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                        threshold: "BLOCK_MEDIUM_AND_ABOVE"
                    },
                    {
                        category: "HARM_CATEGORY_DANGEROUS_CONTENT",
                        threshold: "BLOCK_MEDIUM_AND_ABOVE"
                    }
                ]
            };

            console.log("正在调用Gemini 2.5 Flash API...", { apiUrl, payload });

            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (compatible; InspirationLoom/1.0)'
                },
                body: JSON.stringify(payload)
            });

            console.log("API响应状态:", response.status, response.statusText);

            if (!response.ok) {
                const errorText = await response.text();
                console.error("API错误详情:", errorText);
                throw new Error(`API调用失败 (状态码: ${response.status}): ${errorText}`);
            }

            const result = await response.json();
            console.log("API响应结果:", result);

            if (result.candidates && result.candidates[0]?.content?.parts?.[0]?.text) {
                const generatedText = result.candidates[0].content.parts[0].text;
                state.storyText += "\n\n" + generatedText;
                console.log("故事生成成功，长度:", generatedText.length);
            } else {
                console.error("API响应格式异常:", result);
                throw new Error("未能从API获取有效的故事内容。请检查API响应格式。");
            }

        } catch (error) {
            console.error("故事生成失败:", error);

            // 提供更详细的错误信息
            let errorMessage = "生成故事时发生错误：";
            if (error.message.includes('403')) {
                errorMessage += "API密钥无效或权限不足";
            } else if (error.message.includes('429')) {
                errorMessage += "API调用频率超限，请稍后重试";
            } else if (error.message.includes('500')) {
                errorMessage += "服务器内部错误，请稍后重试";
            } else {
                errorMessage += error.message;
            }

            state.storyText += `\n\n// ${errorMessage}`;
        } finally {
            state.stage = 'result';
            render();
        }
    });
}


function renderResult() {
    const baseHue = Math.abs(state.warp.style.name.split('').reduce((acc, char) => char.charCodeAt(0) + ((acc << 5) - acc), 0)) % 360;

    const resultHTML = `
        <div class="min-h-screen w-full text-slate-200 flex flex-col items-center p-6 sm:p-8 lg:p-12 animate-fade-in">
            <h1 class="text-4xl font-serif text-amber-300 mb-4">叙事织锦</h1>
            <p class="text-slate-400 mb-8">这是你独一无二的故事纹理</p>
            
            <div class="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div class="bg-slate-800/50 p-6 rounded-lg border border-slate-700">
                    <h2 class="text-2xl font-serif mb-4 flex items-center gap-2">${ICONS.TEXTURE('class="w-6 h-6"')}故事纹理</h2>
                    <div class="w-full aspect-video rounded-lg overflow-hidden border border-slate-700 bg-slate-900 flex items-center justify-center">
                         <svg width="100%" height="100%" viewBox="0 0 400 200">
                            <defs>
                                <filter id="turbulence">
                                    <feTurbulence type="fractalNoise" baseFrequency="${(state.storyText.length % 100) * 0.0001 + 0.02}" numOctaves="3" result="noise" />
                                    <feDiffuseLighting in="noise" lighting-color="hsl(${baseHue}, 90%, 70%)" surfaceScale="2">
                                        <feDistantLight azimuth="45" elevation="60" />
                                    </feDiffuseLighting>
                                </filter>
                            </defs>
                            <rect width="100%" height="100%" fill="hsl(${baseHue}, 40%, 20%)" />
                            <rect width="100%" height="100%" filter="url(#turbulence)" opacity="0.4" />
                        </svg>
                    </div>
                    <p class="text-xs text-slate-500 mt-2 text-center">这幅织锦的纹理由你的故事风格和内容独家生成。</p>
                </div>

                <div class="bg-slate-800/50 p-6 rounded-lg border border-slate-700 flex flex-col">
                    <h2 class="text-2xl font-serif mb-4">故事卷轴</h2>
                    <div id="story-text-area" class="flex-grow bg-slate-900/70 p-4 rounded-md overflow-y-auto max-h-[400px] whitespace-pre-wrap font-serif leading-relaxed no-scrollbar">${state.storyText.trim()}</div>
                </div>
            </div>

            <div class="mt-12 flex flex-wrap justify-center gap-4">
                 <button id="copy-button" class="px-6 py-3 bg-slate-700 rounded-lg hover:bg-slate-600 transition-colors">复制故事文本</button>
                 <button id="continue-button" class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition-colors">返回织机继续创作</button>
                 <button id="reset-button" class="px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-900 font-bold rounded-lg hover:shadow-lg hover:shadow-amber-500/20 transition-all">开启新的织造</button>
            </div>
        </div>
    `;
    app.innerHTML = resultHTML;

    // Event listeners
    document.getElementById('copy-button').addEventListener('click', () => {
        navigator.clipboard.writeText(document.getElementById('story-text-area').innerText)
            .then(() => alert('故事已复制到剪贴板！'))
            .catch(err => console.error('复制失败', err));
    });

    document.getElementById('continue-button').addEventListener('click', () => {
        state.stage = 'weaving';
        render();
    });

    document.getElementById('reset-button').addEventListener('click', () => {
        // Reset state
        Object.assign(state, {
            stage: 'setup',
            warp: { era: null, world: null, style: null },
            characters: [],
            plots: [],
            storyText: "",
        });
        render();
    });
}


// --- 同步编织动画类 ---
class SynchronizedWeavingAnimation {
    constructor() {
        this.container = document.querySelector('.loom-container');
        this.warpContainer = document.querySelector('.warp-threads');
        this.spindleContainer = document.querySelector('.spindles');
        this.textFabric = document.querySelector('.text-fabric');
        this.fabricOverlay = document.querySelector('.fabric-overlay');
        this.floatingContainer = document.querySelector('.floating-threads');

        this.init();
    }

    init() {
        // 立即创建背景飘动丝线
        this.createFloatingThreads();
        // 延迟开始同步动画
        setTimeout(() => this.startSynchronizedWeaving(), 1500);
    }

    // 创建背景飘动丝线
    createFloatingThreads() {
        for (let i = 0; i < 25; i++) {
            const thread = document.createElement('div');
            thread.className = 'floating-thread';
            thread.style.left = Math.random() * 100 + '%';
            thread.style.top = Math.random() * 100 + '%';
            thread.style.animationDelay = Math.random() * 3 + 's';
            thread.style.animationDuration = (4 + Math.random() * 2) + 's';
            this.floatingContainer.appendChild(thread);
        }
    }

    // 同步编织动画：文字和编织过程一起出现
    startSynchronizedWeaving() {
        // 1. 文字开始浮现
        this.textFabric.style.animation = 'textWeaveSync 3s ease-out forwards';

        // 2. 同时开始经线生长
        this.createWarpThreads();

        // 3. 稍后开始纺锤和光点
        setTimeout(() => this.createSpindlesAndParticles(), 800);

        // 4. 织物纹理最后出现
        setTimeout(() => {
            this.fabricOverlay.style.animation = 'fabricRevealSync 2s ease-out forwards';
        }, 2500);

        // 5. 最终光效
        setTimeout(() => this.addFinalGlow(), 3500);
    }

    // 创建经线
    createWarpThreads() {
        const warpCount = 12;
        const spacing = 45;
        const startX = (600 - spacing * (warpCount - 1)) / 2;

        for (let i = 0; i < warpCount; i++) {
            const warp = document.createElement('div');
            warp.className = 'warp-thread';
            warp.style.left = `${startX + i * spacing}px`;
            warp.style.animationDelay = `${i * 0.1}s`;
            warp.style.animation = 'warpGrowSync 2s ease-out forwards';

            this.warpContainer.appendChild(warp);
        }
    }

    // 创建纺锤和光点粒子
    createSpindlesAndParticles() {
        const spindlePositions = [120, 220, 320, 420];
        const threadColors = ['#FF6B6B', '#4ECDC4', '#FFD93D', '#6BCF7F'];

        spindlePositions.forEach((pos, index) => {
            // 创建光点粒子效果
            this.createLightParticles(pos, threadColors[index]);

            setTimeout(() => {
                // 创建纺锤
                const spindle = document.createElement('div');
                spindle.className = 'spindle';
                spindle.style.left = `${pos}px`;
                spindle.style.animation = 'fadeInSync 1s ease-out forwards';
                this.spindleContainer.appendChild(spindle);

                // 创建缠绕的丝线
                for (let i = 0; i < 4; i++) {
                    const thread = document.createElement('div');
                    thread.className = 'thread';
                    thread.style.background = threadColors[index];
                    thread.style.left = `${pos}px`;
                    thread.style.bottom = `${i * 6}px`;
                    thread.style.transformOrigin = `${2 + Math.random() * 2}px bottom`;
                    thread.style.animationDelay = `${i * 0.2}s`;
                    thread.style.animation = 'threadWindSync 1.5s ease-out forwards';
                    thread.style.boxShadow = `0 0 4px ${threadColors[index]}`;

                    this.spindleContainer.appendChild(thread);
                }
            }, index * 150);
        });
    }

    // 创建光点粒子效果
    createLightParticles(targetPos, color) {
        const particleCount = 6;

        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('div');
            particle.className = 'light-particle';
            particle.style.background = `radial-gradient(circle, ${color}, transparent)`;
            particle.style.boxShadow = `0 0 6px ${color}`;

            // 随机起始位置（从边缘）
            const side = Math.floor(Math.random() * 4);
            let startX, startY;

            switch(side) {
                case 0: startX = Math.random() * window.innerWidth; startY = 0; break;
                case 1: startX = window.innerWidth; startY = Math.random() * window.innerHeight; break;
                case 2: startX = Math.random() * window.innerWidth; startY = window.innerHeight; break;
                case 3: startX = 0; startY = Math.random() * window.innerHeight; break;
            }

            particle.style.left = `${startX}px`;
            particle.style.top = `${startY}px`;
            this.container.appendChild(particle);

            // 动画到目标位置
            setTimeout(() => {
                const weavingArea = document.querySelector('.weaving-area');
                const rect = weavingArea.getBoundingClientRect();

                particle.style.transition = 'all 1.5s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
                particle.style.left = `${rect.left + targetPos}px`;
                particle.style.top = `${rect.bottom - 40}px`;
                particle.style.opacity = '1';

                setTimeout(() => {
                    particle.style.animation = 'particleTravelSync 0.6s ease-out forwards';
                }, 1200);

                setTimeout(() => particle.remove(), 2000);
            }, i * 100);
        }
    }

    // 添加最终光效
    addFinalGlow() {
        const logo = document.querySelector('.logo');
        if (logo) {
            logo.style.filter = 'drop-shadow(0 0 20px rgba(255,255,255,0.4))';

            // 微妙的脉冲效果
            setInterval(() => {
                logo.style.textShadow = `
                    0 0 25px rgba(255,255,255,${0.3 + Math.random() * 0.2}),
                    0 0 50px rgba(255,215,0,${0.1 + Math.random() * 0.1})
                `;
            }, 2000);
        }
    }
}

// --- 初始化应用 ---
// 首次加载时调用主渲染函数
render();

