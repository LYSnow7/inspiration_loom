// --- 全局状态管理 ---
// 用一个对象来管理整个应用的状态，替代 React 的 useState
const state = {
    stage: 'intro', // 当前阶段: 'intro', 'setup', 'creation', 'weaving', 'result'
    warp: { era: null, world: null, style: null }, // 经线 (故事框架)
    characters: [], // 角色列表
    plots: [], // 情节列表
    storyText: "", // 生成的故事文本
    // 创作界面状态
    activeConstellation: null, // 当前激活的星座: 'characters' | 'plot' | null
    isGenerating: false, // 是否正在生成故事
    storyData: {
        characters: "",
        plot: "",
        generatedStory: ""
    }
};

// --- DOM 节点 ---
const app = document.getElementById('app');

// --- SVG 图标 ---
// 将 React 组件转换为返回 SVG 字符串的函数
const ICONS = {
    SPINDLE: (props) => `<svg ${props} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" xmlns="http://www.w3.org/2000/svg"><path d="M12 2L15 5L12 8L9 5L12 2Z" stroke-linejoin="round"/><path d="M12 22L15 19L12 16L9 19L12 22Z" stroke-linejoin="round"/><path d="M5 15L2 12L5 9" stroke-linejoin="round"/><path d="M19 15L22 12L19 9" stroke-linejoin="round"/><path d="M12 8V16" /><path d="M15 5C17.5 7.5 17.5 16.5 15 19" /><path d="M9 5C6.5 7.5 6.5 16.5 9 19" /></svg>`,
    SHUTTLE: (props) => `<svg ${props} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2 32C2 32 12 4 32 4C52 4 62 32 62 32C62 32 52 60 32 60C12 60 2 32 2 32Z" stroke="currentColor" stroke-width="3" /><circle cx="32" cy="32" r="8" fill="currentColor" /></svg>`,
    THREAD: (props) => `<svg ${props} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 3C12 3 6 4.5 6 9C6 13.5 12 15 12 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M12 15C12 15 18 16.5 18 21C18 25.5 12 27 12 27" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" opacity="0.6"/><path d="M12 15C12 15 6 16.5 6 21C6 25.5 12 27 12 27" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" opacity="0.6"/><path d="M12 3C12 3 18 4.5 18 9C18 13.5 12 15 12 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
    TEXTURE: (props) => `<svg ${props} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" xmlns="http://www.w3.org/2000/svg"><path d="M3 5.2C3 5.2 4.2 4 6 4C7.8 4 9 5.2 9 5.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 12C3 12 4.2 10.8 6 10.8C7.8 10.8 9 12 9 12" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 18.8C3 18.8 4.2 17.6 6 17.6C7.8 17.6 9 18.8 9 18.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 5.2C15 5.2 16.2 4 18 4C19.8 4 21 5.2 21 5.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 12C15 12 16.2 10.8 18 10.8C19.8 10.8 21 12 21 12" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 18.8C15 18.8 16.2 17.6 18 17.6C19.8 17.6 21 18.8 21 18.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
    // 新增创作界面需要的图标
    SPARKLES: (props) => `<svg ${props} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" xmlns="http://www.w3.org/2000/svg"><path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .962 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.582a.5.5 0 0 1 0 .962L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.962 0z"/><path d="M20 3v4"/><path d="M22 5h-4"/><path d="M4 17v2"/><path d="M5 18H3"/></svg>`,
    USERS: (props) => `<svg ${props} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" xmlns="http://www.w3.org/2000/svg"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="m22 21-3.5-3.5"/><circle cx="17" cy="17" r="3"/></svg>`,
    BOOK_OPEN: (props) => `<svg ${props} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" xmlns="http://www.w3.org/2000/svg"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>`,
    WAND2: (props) => `<svg ${props} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" xmlns="http://www.w3.org/2000/svg"><path d="M21.64 3.64l-1.28-1.28a1.21 1.21 0 0 0-1.72 0L2.36 18.64a1.21 1.21 0 0 0 0 1.72l1.28 1.28a1.2 1.2 0 0 0 1.72 0L21.64 5.36a1.2 1.2 0 0 0 0-1.72"/><path d="m14 7 3 3"/><path d="M5 6v4"/><path d="M19 14v4"/><path d="M10 2v2"/><path d="M7 8H3"/><path d="M21 16h-4"/><path d="M11 3H9"/></svg>`,
};

// --- 数据 (已更新) ---
const WARP_OPTIONS = {
    era: [
        { name: "远古洪荒", icon: "🦖", description: "巨兽漫步，神话初生" },
        { name: "奇幻中世纪", icon: "🏰", description: "骑士与魔法，龙与传说" },
        { name: "武侠江湖", icon: "🗡️", description: "刀光剑影，快意恩仇" },
        { name: "蒸汽朋克", icon: "⚙️", description: "齿轮与奥秘，工业的轰鸣" },
        { name: "现代都市", icon: "🏢", description: "车水马龙，霓虹下的罪与爱" },
        { name: "赛博纪元", icon: "🌃", description: "霓虹与义体，高科技低生活" },
        { name: "末日废土", icon: "☢️", description: "文明的余烬，生存的挣扎" },
        { name: "星际未来", icon: "🚀", description: "深空探索，文明的碰撞" },
    ],
    world: [
        { name: "失落的古城", icon: "🏛️", description: "被遗忘的文明遗迹" },
        { name: "无尽的沙漠", icon: "🏜️", description: "烈日与流沙下的秘密" },
        { name: "浮空的岛屿", icon: "🏝️", description: "云海之上的奇迹国度" },
        { name: "幽深的森林", icon: "🌳", description: "古老树木间的精灵低语" },
        { name: "深海王国", icon: "🐠", description: "珊瑚与宫殿，遗忘的旋律" },
        { name: "云顶天宫", icon: "☁️", description: "仙雾缭绕，众神的居所" },
        { name: "机械都市", icon: "🤖", description: "精准与冰冷，秩序的堡垒" },
        { name: "繁华的都市", icon: "🏙️", description: "钢铁丛林中的万千故事" },
    ],
    style: [
        { name: "悬疑", icon: "❓", color: "from-indigo-400 to-slate-700" },
        { name: "浪漫", icon: "❤️", color: "from-rose-400 to-red-500" },
        { name: "史诗", icon: "⚔️", color: "from-amber-400 to-orange-600" },
        { name: "治愈", icon: "✨", color: "from-emerald-300 to-teal-500" },
        { name: "科幻", icon: "👩‍🚀", color: "from-sky-400 to-indigo-600" },
        { name: "喜剧", icon: "😂", color: "from-yellow-300 to-green-400" },
        { name: "哲理", icon: "🧠", color: "from-slate-400 to-gray-500" },
        { name: "恐怖", icon: "👻", color: "from-gray-700 to-black" },
    ],
};

const KEYWORD_COLORS = [ 'text-red-400', 'text-blue-400', 'text-green-400', 'text-yellow-400', 'text-purple-400', 'text-pink-400', 'text-indigo-400', 'text-teal-400', 'text-orange-400' ];
const getKeywordColor = (str) => {
    let hash = 0;
    for (let i = 0; i < str.length; i++) { hash = str.charCodeAt(i) + ((hash << 5) - hash); }
    return KEYWORD_COLORS[Math.abs(hash) % KEYWORD_COLORS.length];
};

// --- 渲染函数 ---

/**
 * 主渲染函数，根据 state.stage 决定显示哪个界面
 */
function render() {
    console.log('render被调用，当前stage:', state.stage);
    // 清空主容器
    app.innerHTML = '';
    // 根据当前阶段渲染对应内容
    switch (state.stage) {
        case 'intro':
            renderIntro();
            break;
        case 'setup':
            renderSetup();
            break;
        case 'creation':
            renderCreation();
            break;
        case 'result':
            renderResult();
            break;
    }
}

function renderIntro() {
    // 使用synchronized-weaving.html中的精美加载动画
    const introHTML = `
        <div id="intro-container" class="fixed inset-0 transition-opacity duration-1000 opacity-100">
            <style>
                .loom-container {
                    position: relative;
                    width: 100vw;
                    height: 100vh;
                    overflow: hidden;
                    background: #0f172a;
                }

                /* 微光背景 */
                .ambient-light {
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    width: 500px;
                    height: 500px;
                    background: radial-gradient(circle, rgba(255,255,255,0.05) 0%, transparent 70%);
                    transform: translate(-50%, -50%);
                    animation: breathe 4s ease-in-out infinite;
                }

                @keyframes breathe {
                    0%, 100% { transform: translate(-50%, -50%) scale(0.8); opacity: 0.3; }
                    50% { transform: translate(-50%, -50%) scale(1.2); opacity: 0.6; }
                }

                /* 背景飘动的丝线 */
                .floating-thread {
                    position: absolute;
                    width: 1px;
                    height: 30px;
                    background: linear-gradient(180deg, transparent, rgba(251,191,36,0.4), transparent);
                    opacity: 0.3;
                    animation: floatThread 6s ease-in-out infinite;
                    pointer-events: none;
                    z-index: 1;
                }

                @keyframes floatThread {
                    0%, 100% {
                        transform: translateY(0) rotate(0deg);
                        opacity: 0.2;
                    }
                    25% {
                        transform: translateY(-15px) rotate(45deg);
                        opacity: 0.5;
                    }
                    50% {
                        transform: translateY(-8px) rotate(90deg);
                        opacity: 0.7;
                    }
                    75% {
                        transform: translateY(-20px) rotate(135deg);
                        opacity: 0.4;
                    }
                }

                /* 文字区域 - 中央 */
                .text-fabric {
                    position: absolute;
                    top: 45%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    text-align: center;
                    opacity: 0;
                    z-index: 10;
                    background: rgba(15, 23, 42, 0.7);
                    padding: 40px 50px;
                    border-radius: 20px;
                    backdrop-filter: blur(15px);
                    border: 1px solid rgba(255,255,255,0.1);
                }

                .logo {
                    font-size: 64px;
                    font-weight: bold;
                    margin-bottom: 20px;
                    background: linear-gradient(45deg, #FFD700, #FF6B6B, #4ECDC4, #45B7D1);
                    background-size: 400% 400%;
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                    background-clip: text;
                    animation: gradientShift 3s ease-in-out infinite;
                    text-shadow: 0 0 20px rgba(255,255,255,0.3);
                }

                .subtitle {
                    font-size: 24px;
                    color: #bbb;
                    margin-bottom: 15px;
                    letter-spacing: 1px;
                }

                .slogan {
                    font-size: 18px;
                    color: #999;
                    font-weight: 300;
                    letter-spacing: 0.5px;
                }

                @keyframes gradientShift {
                    0%, 100% { background-position: 0% 50%; }
                    50% { background-position: 100% 50%; }
                }

                /* 编织区域 - 下方 */
                .weaving-area {
                    position: absolute;
                    bottom: 15%;
                    left: 50%;
                    transform: translateX(-50%);
                    width: 600px;
                    height: 200px;
                    z-index: 5;
                }

                /* 经线 */
                .warp-thread {
                    position: absolute;
                    width: 1px;
                    height: 0;
                    background: linear-gradient(to bottom, transparent, rgba(255,255,255,0.8), transparent);
                    top: 0;
                    transform: translateX(-50%);
                    opacity: 0;
                    box-shadow: 0 0 6px rgba(255,255,255,0.6);
                }

                /* 纺锤 */
                .spindle {
                    position: absolute;
                    bottom: 0;
                    width: 6px;
                    height: 40px;
                    background: linear-gradient(to bottom, #8B4513, #CD853F, #8B4513);
                    border-radius: 3px;
                    opacity: 0;
                    transform: translateX(-50%);
                }

                /* 丝线 */
                .thread {
                    position: absolute;
                    width: 1px;
                    height: 25px;
                    border-radius: 0.5px;
                    opacity: 0;
                    transform-origin: bottom center;
                }

                /* 光点粒子 */
                .light-particle {
                    position: absolute;
                    width: 3px;
                    height: 3px;
                    background: radial-gradient(circle, rgba(255,255,255,0.9), transparent);
                    border-radius: 50%;
                    opacity: 0;
                }

                /* 同步动画关键帧 */
                @keyframes warpGrowSync {
                    0% {
                        height: 0;
                        opacity: 0;
                    }
                    100% {
                        height: 180px;
                        opacity: 1;
                    }
                }

                @keyframes textWeaveSync {
                    0% {
                        opacity: 0;
                        transform: translate(-50%, -50%) scale(0.8);
                        filter: blur(10px);
                    }
                    30% {
                        opacity: 0.3;
                        transform: translate(-50%, -50%) scale(0.9);
                        filter: blur(5px);
                    }
                    60% {
                        opacity: 0.7;
                        transform: translate(-50%, -50%) scale(1.02);
                        filter: blur(2px);
                    }
                    100% {
                        opacity: 1;
                        transform: translate(-50%, -50%) scale(1);
                        filter: blur(0px);
                    }
                }

                @keyframes threadWindSync {
                    0% {
                        opacity: 0;
                        transform: rotate(0deg) scale(0);
                    }
                    50% {
                        opacity: 0.5;
                        transform: rotate(180deg) scale(0.7);
                    }
                    100% {
                        opacity: 0.9;
                        transform: rotate(360deg) scale(1);
                    }
                }

                @keyframes particleTravelSync {
                    0% {
                        opacity: 1;
                        transform: scale(1);
                    }
                    50% {
                        opacity: 0.9;
                        transform: scale(1.2);
                    }
                    90% {
                        opacity: 0.8;
                    }
                    100% {
                        opacity: 0;
                        transform: scale(0.3);
                    }
                }

                @keyframes fadeInSync {
                    0% { opacity: 0; transform: translateY(10px); }
                    100% { opacity: 1; transform: translateY(0); }
                }

                /* 织物纹理效果 */
                .fabric-overlay {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    opacity: 0;
                    background:
                        repeating-linear-gradient(
                            0deg,
                            transparent,
                            transparent 2px,
                            rgba(255,255,255,0.008) 2px,
                            rgba(255,255,255,0.008) 4px
                        ),
                        repeating-linear-gradient(
                            90deg,
                            transparent,
                            transparent 2px,
                            rgba(255,255,255,0.004) 2px,
                            rgba(255,255,255,0.004) 4px
                        );
                    pointer-events: none;
                }

                @keyframes fabricRevealSync {
                    0% { opacity: 0; }
                    100% { opacity: 1; }
                }
            </style>

            <div class="loom-container">
                <!-- 微光背景 -->
                <div class="ambient-light"></div>

                <!-- 织物纹理叠加层 -->
                <div class="fabric-overlay"></div>

                <!-- 背景飘动丝线 -->
                <div class="floating-threads"></div>

                <!-- 文字区域 -->
                <div class="text-fabric">
                    <div class="logo">灵感织机</div>
                    <div class="subtitle">Inspiration Loom</div>
                    <div class="slogan">编织属于你的叙事纹理</div>
                </div>

                <!-- 编织区域 -->
                <div class="weaving-area">
                    <div class="warp-threads"></div>
                    <div class="spindles"></div>
                </div>
            </div>
        </div>
    `;
    app.innerHTML = introHTML;

    // 启动同步编织动画
    const weavingAnimation = new SynchronizedWeavingAnimation();

    // 设置一个定时器，在5秒后过渡到下一个阶段
    setTimeout(() => {
        const introContainer = document.getElementById('intro-container');
        if (introContainer) {
            introContainer.classList.replace('opacity-100', 'opacity-0');
        }
        // 在淡出动画结束后，渲染设置界面
        setTimeout(() => {
            state.stage = 'setup';
            render();
        }, 1000); // 等待淡出动画完成
    }, 5000); // 动画总时长为5秒
}


function renderSetup(step = 0) {
    const steps = [
        { title: "第一步: 选择时代经线", category: "era", options: WARP_OPTIONS.era, prompt: "故事发生在哪个时代？" },
        { title: "第二步: 设定世界经线", category: "world", options: WARP_OPTIONS.world, prompt: "它的舞台在何处？" },
        { title: "第三步: 定义故事纹理", category: "style", options: WARP_OPTIONS.style, prompt: "你希望它呈现何种质感？" }
    ];

    if (step >= steps.length) {
        state.stage = 'creation';
        render();
        return;
    }

    const currentStep = steps[step];
    const setupHTML = `
        <div class="min-h-screen w-full text-slate-200 flex flex-col justify-center items-center p-4 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-800 relative">

            <!-- 背景星尘 -->
            <div class="absolute inset-0 overflow-hidden pointer-events-none">
                <div class="absolute top-[10%] left-[15%] w-2 h-2 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 4s;"></div>
                <div class="absolute top-[25%] right-[20%] w-1 h-1 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 6s;"></div>
                <div class="absolute top-[40%] left-[8%] w-1.5 h-1.5 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 5s;"></div>
                <div class="absolute top-[60%] right-[12%] w-1 h-1 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 7s;"></div>
                <div class="absolute top-[75%] left-[25%] w-2 h-2 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 4.5s;"></div>
                <div class="absolute top-[15%] left-[60%] w-1 h-1 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 6.5s;"></div>
                <div class="absolute top-[35%] right-[35%] w-1.5 h-1.5 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 5.5s;"></div>
                <div class="absolute top-[80%] right-[40%] w-1 h-1 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 7.5s;"></div>
                <div class="absolute top-[20%] left-[80%] w-2 h-2 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 4.2s;"></div>
                <div class="absolute top-[65%] left-[70%] w-1.5 h-1.5 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 6.8s;"></div>
            </div>
            <div class="relative z-10 text-center w-full max-w-7xl animate-fade-in">
                <p class="text-amber-300 font-serif mb-2">${currentStep.title}</p>
                <h2 class="text-4xl font-serif mb-12">${currentStep.prompt}</h2>
                <div class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-4 md:gap-6">
                    ${currentStep.options.map(option => `
                        <div class="relative group flex justify-center">
                            <button class="setup-option aspect-square bg-slate-800/50 border border-slate-700 rounded-xl flex flex-col justify-center items-center p-4 hover:bg-slate-700 hover:border-amber-400 hover:scale-105 transition-all duration-300"
                                    data-category="${currentStep.category}" data-value='${JSON.stringify(option)}'>
                                <span class="text-5xl mb-2">${option.icon}</span>
                                <span class="font-serif text-lg text-center">${option.name}</span>
                            </button>
                            <div class="absolute bottom-full mb-2 w-max px-3 py-1.5 text-sm text-white bg-gray-800 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                                ${option.description || option.name}
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
            <div class="fixed bottom-8 flex space-x-4">
                ${steps.map((s, i) => `<div class="w-3 h-3 rounded-full transition-colors duration-300 ${step >= i ? 'bg-amber-400' : 'bg-slate-600'}"></div>`).join('')}
            </div>
        </div>
    `;
    app.innerHTML = setupHTML;

    // 添加事件监听器
    document.querySelectorAll('.setup-option').forEach(button => {
        button.addEventListener('click', (e) => {
            const target = e.currentTarget;
            const category = target.dataset.category;
            const value = JSON.parse(target.dataset.value);
            state.warp[category] = value;
            setTimeout(() => renderSetup(step + 1), 300);
        });
    });
}

function renderCreation() {
    const creationHTML = `
        <div class="relative min-h-screen bg-gradient-to-b from-slate-900 via-purple-900 to-slate-900 overflow-hidden">
            <!-- 流动星空背景 -->
            <div class="absolute inset-0">
                <div class="stars"></div>
                <div class="twinkling"></div>
                <div class="clouds"></div>
            </div>

            <!-- 中央星象仪 -->
            <div class="absolute inset-0 flex items-center justify-center">
                <div class="astrolabe-container">
                    <!-- 外环 -->
                    <div class="astrolabe-ring outer-ring">
                        <div class="ring-decoration"></div>
                    </div>

                    <!-- 中环 -->
                    <div class="astrolabe-ring middle-ring">
                        <div class="ring-decoration"></div>
                    </div>

                    <!-- 内环 -->
                    <div class="astrolabe-ring inner-ring">
                        <div class="ring-decoration"></div>
                    </div>

                    <!-- 中央核心 -->
                    <div class="astrolabe-core">
                        <div class="core-symbol">
                            ${ICONS.SPARKLES('class="w-8 h-8 text-purple-300"')}
                        </div>
                    </div>
                </div>

                <!-- 角色星座 -->
                <div class="constellation characters-constellation ${state.activeConstellation === 'characters' ? 'active' : ''}"
                     id="characters-constellation">
                    <div class="constellation-symbol">
                        ${ICONS.USERS('class="w-6 h-6"')}
                    </div>
                    <div class="constellation-glow"></div>
                    <span class="constellation-label">角色星座</span>
                </div>

                <!-- 情节星座 -->
                <div class="constellation plot-constellation ${state.activeConstellation === 'plot' ? 'active' : ''}"
                     id="plot-constellation">
                    <div class="constellation-symbol">
                        ${ICONS.BOOK_OPEN('class="w-6 h-6"')}
                    </div>
                    <div class="constellation-glow"></div>
                    <span class="constellation-label">情节星座</span>
                </div>
            </div>

            <!-- 输入卡片 -->
            ${state.activeConstellation ? `
                <div class="fixed inset-0 flex items-center justify-center z-50 pointer-events-none">
                    <div class="glass-card pointer-events-auto max-w-md w-full mx-4 rounded-lg border bg-card text-card-foreground shadow-sm">
                        <div class="p-6 space-y-4">
                            <h3 class="text-xl font-semibold text-purple-100 flex items-center gap-2">
                                ${state.activeConstellation === 'characters' ? `
                                    ${ICONS.USERS('class="w-5 h-5"')}
                                    角色设定
                                ` : `
                                    ${ICONS.BOOK_OPEN('class="w-5 h-5"')}
                                    情节构思
                                `}
                            </h3>
                            <textarea
                                id="story-input"
                                placeholder="${state.activeConstellation === 'characters' ? '描述你的角色：他们是谁？有什么特点？' : '描述你的情节：故事将如何展开？'}"
                                class="glass-textarea min-h-[120px] text-purple-100 placeholder:text-purple-300 flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                            >${state.activeConstellation === 'characters' ? state.storyData.characters : state.storyData.plot}</textarea>
                            <button id="complete-input" class="w-full crystal-button inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-10 px-4 py-2">
                                完成
                            </button>
                        </div>
                    </div>
                </div>
            ` : ''}

            <!-- 织造按钮 -->
            ${state.storyData.characters && state.storyData.plot ? `
                <div class="fixed bottom-8 left-1/2 transform -translate-x-1/2 z-40">
                    <button id="weave-button" ${state.isGenerating ? 'disabled' : ''} class="weave-button inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-11 rounded-md px-8">
                        ${ICONS.WAND2('class="w-5 h-5 mr-2"')}
                        ${state.isGenerating ? '织造中...' : '织造命运'}
                    </button>
                </div>
            ` : ''}
        </div>
    `;

    app.innerHTML = creationHTML;

    // 添加样式
    addCreationStyles();

    // 添加事件监听器
    addCreationEventListeners();
}

// 添加创作界面样式
function addCreationStyles() {
    // 检查是否已经添加了样式
    if (document.getElementById('creation-styles')) return;

    const style = document.createElement('style');
    style.id = 'creation-styles';
    style.textContent = `
        /* 星空背景样式 */
        .stars {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: transparent url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="0.5" fill="white" opacity="0.8"/><circle cx="80" cy="40" r="0.3" fill="white" opacity="0.6"/><circle cx="40" cy="60" r="0.4" fill="white" opacity="0.7"/><circle cx="90" cy="80" r="0.2" fill="white" opacity="0.5"/><circle cx="10" cy="90" r="0.6" fill="white" opacity="0.9"/></svg>') repeat;
            animation: move-stars 50s linear infinite;
        }

        .twinkling {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: transparent url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="30" cy="30" r="0.3" fill="white" opacity="0.4"/><circle cx="70" cy="70" r="0.2" fill="white" opacity="0.6"/><circle cx="50" cy="10" r="0.4" fill="white" opacity="0.3"/></svg>') repeat;
            animation: move-twinkle 100s linear infinite;
        }

        .clouds {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(ellipse at center, rgba(147, 51, 234, 0.1) 0%, transparent 70%);
            animation: drift 200s ease-in-out infinite alternate;
        }

        @keyframes move-stars {
            from { transform: translateY(0px); }
            to { transform: translateY(-2000px); }
        }

        @keyframes move-twinkle {
            from { transform: translateY(0px); }
            to { transform: translateY(-2000px); }
        }

        @keyframes drift {
            from { transform: rotate(0deg) scale(1); }
            to { transform: rotate(360deg) scale(1.1); }
        }

        .astrolabe-container {
            position: relative;
            width: 400px;
            height: 400px;
        }

        .astrolabe-ring {
            position: absolute;
            border: 2px solid rgba(192, 132, 252, 0.3);
            border-radius: 50%;
            box-shadow:
                0 0 20px rgba(147, 51, 234, 0.3),
                inset 0 0 20px rgba(147, 51, 234, 0.1);
        }

        .outer-ring {
            width: 100%;
            height: 100%;
            animation: rotate-slow 60s linear infinite;
        }

        .middle-ring {
            width: 70%;
            height: 70%;
            top: 15%;
            left: 15%;
            animation: rotate-medium 40s linear infinite reverse;
        }

        .inner-ring {
            width: 40%;
            height: 40%;
            top: 30%;
            left: 30%;
            animation: rotate-fast 20s linear infinite;
        }

        .astrolabe-core {
            position: absolute;
            width: 80px;
            height: 80px;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: radial-gradient(circle, rgba(147, 51, 234, 0.2) 0%, transparent 70%);
            border: 2px solid rgba(192, 132, 252, 0.5);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 0 30px rgba(147, 51, 234, 0.5);
        }

        .core-symbol {
            animation: pulse 2s ease-in-out infinite;
        }

        @keyframes rotate-slow {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        @keyframes rotate-medium {
            from { transform: rotate(0deg); }
            to { transform: rotate(-360deg); }
        }

        @keyframes rotate-fast {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        @keyframes pulse {
            0%, 100% { opacity: 0.7; transform: scale(1); }
            50% { opacity: 1; transform: scale(1.1); }
        }

        .constellation {
            position: absolute;
            width: 80px;
            height: 80px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .characters-constellation {
            top: 20%;
            right: 15%;
            animation: orbit-characters 30s linear infinite;
        }

        .plot-constellation {
            bottom: 20%;
            left: 15%;
            animation: orbit-plot 25s linear infinite reverse;
        }

        .constellation-symbol {
            width: 60px;
            height: 60px;
            background: rgba(147, 51, 234, 0.2);
            border: 2px solid rgba(192, 132, 252, 0.6);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: rgba(192, 132, 252, 0.9);
            box-shadow: 0 0 20px rgba(147, 51, 234, 0.4);
            transition: all 0.3s ease;
        }

        .constellation-glow {
            position: absolute;
            top: -10px;
            left: -10px;
            right: -10px;
            bottom: -10px;
            background: radial-gradient(circle, rgba(147, 51, 234, 0.3) 0%, transparent 70%);
            border-radius: 50%;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .constellation-label {
            position: absolute;
            top: 70px;
            left: 50%;
            transform: translateX(-50%);
            color: rgba(192, 132, 252, 0.8);
            font-size: 12px;
            white-space: nowrap;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .constellation:hover .constellation-glow,
        .constellation.active .constellation-glow {
            opacity: 1;
        }

        .constellation:hover .constellation-label,
        .constellation.active .constellation-label {
            opacity: 1;
        }

        .constellation:hover .constellation-symbol,
        .constellation.active .constellation-symbol {
            transform: scale(1.1);
            box-shadow: 0 0 30px rgba(147, 51, 234, 0.6);
        }

        @keyframes orbit-characters {
            from { transform: rotate(0deg) translateX(150px) rotate(0deg); }
            to { transform: rotate(360deg) translateX(150px) rotate(-360deg); }
        }

        @keyframes orbit-plot {
            from { transform: rotate(0deg) translateX(150px) rotate(0deg); }
            to { transform: rotate(-360deg) translateX(150px) rotate(360deg); }
        }

        .glass-card {
            background: rgba(15, 23, 42, 0.3);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(192, 132, 252, 0.2);
            box-shadow:
                0 8px 32px rgba(0, 0, 0, 0.3),
                0 0 0 1px rgba(192, 132, 252, 0.1);
        }

        .glass-textarea {
            background: rgba(15, 23, 42, 0.2);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(192, 132, 252, 0.3);
        }

        .crystal-button {
            background: linear-gradient(135deg, rgba(147, 51, 234, 0.3) 0%, rgba(79, 70, 229, 0.3) 100%);
            border: 1px solid rgba(192, 132, 252, 0.4);
            color: rgba(192, 132, 252, 0.9);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 15px rgba(147, 51, 234, 0.2);
        }

        .crystal-button:hover {
            background: linear-gradient(135deg, rgba(147, 51, 234, 0.4) 0%, rgba(79, 70, 229, 0.4) 100%);
            box-shadow: 0 6px 20px rgba(147, 51, 234, 0.3);
        }

        .weave-button {
            background: linear-gradient(135deg, rgba(147, 51, 234, 0.6) 0%, rgba(79, 70, 229, 0.6) 100%);
            border: 2px solid rgba(192, 132, 252, 0.6);
            color: white;
            backdrop-filter: blur(15px);
            box-shadow:
                0 8px 25px rgba(147, 51, 234, 0.4),
                0 0 0 1px rgba(192, 132, 252, 0.2);
            animation: weave-glow 2s ease-in-out infinite;
        }

        @keyframes weave-glow {
            0%, 100% { box-shadow: 0 8px 25px rgba(147, 51, 234, 0.4), 0 0 0 1px rgba(192, 132, 252, 0.2); }
            50% { box-shadow: 0 8px 35px rgba(147, 51, 234, 0.6), 0 0 0 1px rgba(192, 132, 252, 0.4); }
        }

        /* 响应式调整 */
        @media (max-width: 768px) {
            .astrolabe-container {
                width: 300px;
                height: 300px;
            }
        }
    `;
    document.head.appendChild(style);
}

// 添加创作界面事件监听器
function addCreationEventListeners() {
    // 角色星座点击事件
    const charactersConstellation = document.getElementById('characters-constellation');
    if (charactersConstellation) {
        charactersConstellation.addEventListener('click', () => {
            state.activeConstellation = state.activeConstellation === 'characters' ? null : 'characters';
            renderCreation(); // 重新渲染以显示/隐藏输入卡片
        });
    }

    // 情节星座点击事件
    const plotConstellation = document.getElementById('plot-constellation');
    if (plotConstellation) {
        plotConstellation.addEventListener('click', () => {
            state.activeConstellation = state.activeConstellation === 'plot' ? null : 'plot';
            renderCreation(); // 重新渲染以显示/隐藏输入卡片
        });
    }

    // 输入框变化事件
    const storyInput = document.getElementById('story-input');
    if (storyInput) {
        storyInput.addEventListener('input', (e) => {
            const value = e.target.value;
            if (state.activeConstellation === 'characters') {
                state.storyData.characters = value;
            } else if (state.activeConstellation === 'plot') {
                state.storyData.plot = value;
            }
        });
    }

    // 完成按钮点击事件
    const completeButton = document.getElementById('complete-input');
    if (completeButton) {
        completeButton.addEventListener('click', () => {
            state.activeConstellation = null;
            renderCreation(); // 重新渲染以隐藏输入卡片
        });
    }

    // 织造按钮点击事件
    const weaveButton = document.getElementById('weave-button');
    if (weaveButton) {
        weaveButton.addEventListener('click', handleGenerate);
    }
}

// 处理故事生成
async function handleGenerate() {
    if (!state.storyData.characters || !state.storyData.plot) return;

    state.isGenerating = true;
    renderCreation(); // 重新渲染以显示生成状态

    // 模拟故事生成
    setTimeout(() => {
        const generatedStory = `在一个遥远的星系中，${state.storyData.characters}踏上了一段不凡的旅程。${state.storyData.plot}随着命运的齿轮转动，他们的故事在星空中闪闪发光，成为了永恒的传说...`;

        state.storyData.generatedStory = generatedStory;
        state.storyText = generatedStory;
        state.isGenerating = false;

        // 跳转到结果页面
        state.stage = 'result';
        render();
    }, 3000);
}


// 更多渲染函数和逻辑...
function renderWeavingArea() {
    let shuttleContent = { plots: [], chars: [] };

    // Function to re-render the shuttle area
    function updateShuttleView() {
        const shuttleArea = document.getElementById('shuttle-area');
        if (shuttleArea) {
            if (shuttleContent.plots.length === 0 && shuttleContent.chars.length === 0) {
                shuttleArea.innerHTML = `
                    <div class="text-center">
                        <p class="text-slate-400 text-sm font-medium mb-2">梭子空闲中</p>
                        <p class="text-slate-500 text-xs">拖入情节和角色开始编织</p>
                    </div>
                `;
            } else {
                shuttleArea.innerHTML = `
                    <div class="space-y-2">
                        ${shuttleContent.plots.length > 0 ? `
                            <div class="bg-cyan-400/10 border border-cyan-400/30 rounded-lg p-2 backdrop-blur-sm">
                                <p class="text-cyan-300 text-xs font-medium mb-1 text-center">情节纬线</p>
                                <div class="flex flex-wrap justify-center gap-1 mb-1">
                                    ${shuttleContent.plots.map(plot => `
                                        <span class="text-cyan-200 text-xs bg-cyan-400/20 px-2 py-0.5 rounded-full">${plot.description}</span>
                                    `).join('')}
                                </div>
                            </div>
                        ` : ''}
                        ${shuttleContent.chars.length > 0 ? `
                            <div class="bg-amber-400/10 border border-amber-400/30 rounded-lg p-2 backdrop-blur-sm">
                                <p class="text-amber-300 text-xs font-medium mb-1 text-center">角色丝线</p>
                                <div class="flex flex-wrap justify-center gap-1">
                                    ${shuttleContent.chars.map(c => `<span class="text-amber-200 text-xs bg-amber-400/20 px-2 py-0.5 rounded-full">${c.name}</span>`).join('')}
                                </div>
                            </div>
                        ` : ''}
                    </div>
                `;
            }

            const shuttleIcon = document.getElementById('shuttle-icon-main');
            if (shuttleIcon) {
                if (shuttleContent.plots.length > 0 || shuttleContent.chars.length > 0) {
                    shuttleIcon.classList.add('text-amber-400');
                    shuttleIcon.classList.remove('text-slate-400');
                } else {
                    shuttleIcon.classList.remove('text-amber-400');
                    shuttleIcon.classList.add('text-slate-400');
                }
            }
        }
    }
    
    const weavingHTML = `
        <div class="flex flex-col lg:flex-row h-screen p-4 lg:p-6 gap-6 text-slate-200 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-800 relative">

            <!-- 背景星尘 -->
            <div class="absolute inset-0 overflow-hidden pointer-events-none">
                <div class="absolute top-[10%] left-[15%] w-2 h-2 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 4s;"></div>
                <div class="absolute top-[25%] right-[20%] w-1 h-1 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 6s;"></div>
                <div class="absolute top-[40%] left-[8%] w-1.5 h-1.5 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 5s;"></div>
                <div class="absolute top-[60%] right-[12%] w-1 h-1 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 7s;"></div>
                <div class="absolute top-[75%] left-[25%] w-2 h-2 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 4.5s;"></div>
                <div class="absolute top-[15%] left-[60%] w-1 h-1 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 6.5s;"></div>
                <div class="absolute top-[35%] right-[35%] w-1.5 h-1.5 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 5.5s;"></div>
                <div class="absolute top-[80%] right-[40%] w-1 h-1 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 7.5s;"></div>
                <div class="absolute top-[20%] left-[80%] w-2 h-2 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 4.2s;"></div>
                <div class="absolute top-[65%] left-[70%] w-1.5 h-1.5 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 6.8s;"></div>
            </div>
            <!-- Left Panel: Spindles -->
            <div class="w-full lg:w-96 bg-gradient-to-b from-slate-800/80 to-slate-900/80 backdrop-blur-lg p-6 rounded-2xl border border-slate-600/50 shadow-2xl flex-shrink-0 flex flex-col gap-8 overflow-y-auto no-scrollbar">
                <!-- 角色纺锤区域 -->
                <div class="space-y-4">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="p-2 bg-gradient-to-br from-amber-400 to-orange-500 rounded-lg shadow-lg">
                            ${ICONS.SPINDLE('class="w-6 h-6 text-slate-900"')}
                        </div>
                        <h3 class="text-xl font-serif text-amber-300 font-bold">角色纺锤</h3>
                    </div>
                    <form id="add-char-form" class="relative">
                        <div class="flex gap-3">
                            <div class="flex-grow relative">
                                <input type="text" id="char-name-input" placeholder="新角色名"
                                    class="w-full bg-slate-900/70 border border-slate-600/50 rounded-xl px-4 py-3 text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400/50 focus:border-amber-400 transition-all duration-300 backdrop-blur-sm" />
                                <div class="absolute inset-0 bg-gradient-to-r from-amber-400/5 to-orange-400/5 rounded-xl pointer-events-none"></div>
                            </div>
                            <button type="submit" class="bg-gradient-to-r from-amber-500 to-orange-500 text-slate-900 font-bold rounded-xl px-6 py-3 hover:from-amber-400 hover:to-orange-400 transition-all duration-300 shadow-lg hover:shadow-amber-500/30 transform hover:scale-105">
                                添加
                            </button>
                        </div>
                    </form>
                    <div id="characters-list" class="space-y-3"></div>
                </div>

                <!-- 情节纺锤区域 -->
                <div class="space-y-4">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="p-2 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-lg shadow-lg">
                            ${ICONS.THREAD('class="w-6 h-6 text-slate-900"')}
                        </div>
                        <h3 class="text-xl font-serif text-cyan-300 font-bold">情节纺锤</h3>
                    </div>
                    <form id="add-plot-form" class="relative">
                        <div class="flex gap-3">
                            <div class="flex-grow relative">
                                <input type="text" id="plot-desc-input" placeholder="新情节纬线"
                                    class="w-full bg-slate-900/70 border border-slate-600/50 rounded-xl px-4 py-3 text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400 transition-all duration-300 backdrop-blur-sm" />
                                <div class="absolute inset-0 bg-gradient-to-r from-cyan-400/5 to-blue-400/5 rounded-xl pointer-events-none"></div>
                            </div>
                            <button type="submit" class="bg-gradient-to-r from-cyan-500 to-blue-500 text-slate-900 font-bold rounded-xl px-6 py-3 hover:from-cyan-400 hover:to-blue-400 transition-all duration-300 shadow-lg hover:shadow-cyan-500/30 transform hover:scale-105">
                                添加
                            </button>
                        </div>
                    </form>
                    <div id="plots-list" class="space-y-3"></div>
                </div>
            </div>

            <!-- Right Panel: Weaving Area -->
            <div class="flex-grow flex flex-col items-center justify-between p-8 bg-gradient-to-b from-slate-900/60 to-slate-800/60 backdrop-blur-lg rounded-2xl border border-slate-600/50 shadow-2xl">
                <!-- 经线框架显示 -->
                <div class="relative w-full h-32 mb-8 bg-gradient-to-r from-slate-800/50 to-slate-700/50 rounded-xl p-4 border border-slate-600/30 shadow-inner">
                     <div class="absolute inset-0 flex justify-around items-center px-4">
                        ${Array(9).fill(0).map((_, i) => `<div class="w-px h-full bg-gradient-to-b from-transparent via-amber-300/60 to-transparent shadow-sm"></div>`).join('')}
                    </div>
                    <div class="absolute inset-0 flex flex-col justify-between p-4">
                       <div class="h-2 rounded-full bg-gradient-to-r ${state.warp.style.color} shadow-lg"></div>
                       <div class="text-center py-2 bg-slate-900/30 rounded-lg backdrop-blur-sm">
                           <p class="font-serif text-slate-200 text-lg font-bold">${state.warp.era.name} | ${state.warp.world.name}</p>
                           <p class="text-sm text-slate-400 mt-1">故事纹理: <span class="text-amber-300">${state.warp.style.name}</span></p>
                       </div>
                       <div class="h-2 rounded-full bg-gradient-to-r ${state.warp.style.color} shadow-lg"></div>
                    </div>
                </div>

                <!-- 可用丝线区域 -->
                <div id="draggable-sources" class="w-full mb-8"></div>

                <!-- 梭子区域 -->
                <div id="droppable-shuttle" class="relative flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-3xl transition-all duration-500 border-slate-500/50 bg-gradient-to-br from-slate-800/30 to-slate-900/30 backdrop-blur-sm hover:border-amber-400/50 hover:bg-amber-400/5 group">
                    ${ICONS.SHUTTLE('id="shuttle-icon-main" class="w-40 h-40 text-slate-400 transition-all duration-500 group-hover:text-amber-400 group-hover:scale-105 drop-shadow-lg"')}
                    <div id="shuttle-area" class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-56 text-center pointer-events-none">
                        <!-- shuttle content here -->
                    </div>
                    <p class="mt-4 text-slate-500 text-sm font-medium group-hover:text-amber-400 transition-colors duration-300">将情节与角色拖入梭中开始编织</p>
                </div>

                <!-- 编织按钮 -->
                <button id="weave-button" class="mt-10 w-full max-w-md flex items-center justify-center gap-4 bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 text-slate-900 font-bold text-xl py-5 rounded-2xl shadow-2xl hover:shadow-amber-500/40 transition-all duration-300 transform hover:scale-105 hover:from-amber-400 hover:via-orange-400 hover:to-red-400 relative overflow-hidden group">
                    <div class="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    ${ICONS.SHUTTLE('class="w-8 h-8 relative z-10"')}
                    <span class="relative z-10">引梭织布</span>
                </button>
            </div>
        </div>
    `;
    app.innerHTML = weavingHTML;
    
    // --- Update UI functions ---
    function renderCharacters() {
        const list = document.getElementById('characters-list');
        list.innerHTML = state.characters.map(char => `
            <div class="bg-gradient-to-br from-slate-800/60 to-slate-900/60 backdrop-blur-sm p-4 rounded-xl border border-slate-600/30 shadow-lg hover:shadow-xl transition-all duration-300 hover:border-amber-400/30 group">
                <div class="flex items-center gap-3 mb-3">
                    <div class="w-3 h-3 bg-gradient-to-r from-amber-400 to-orange-500 rounded-full shadow-sm"></div>
                    <p class="font-bold text-slate-200 text-lg group-hover:text-amber-300 transition-colors">${char.name}</p>
                </div>
                <div class="flex flex-wrap gap-2 mb-3">
                    ${char.keywords.map(kw => `<span class="text-xs px-3 py-1 rounded-full bg-gradient-to-r from-slate-700 to-slate-600 ${getKeywordColor(kw)} border border-slate-500/30 shadow-sm hover:shadow-md transition-all duration-200 hover:scale-105">${kw}</span>`).join('')}
                </div>
                <div class="relative">
                    <input type="text" data-char-id="${char.id}" class="keyword-input w-full text-sm bg-slate-900/50 border border-slate-600/50 rounded-lg px-3 py-2 text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400/50 focus:border-amber-400 transition-all duration-300" placeholder="性格丝线 (回车添加)" />
                    <div class="absolute inset-0 bg-gradient-to-r from-amber-400/5 to-orange-400/5 rounded-lg pointer-events-none"></div>
                </div>
            </div>
        `).join('');
        renderDraggables();
    }
    
    function renderPlots() {
        const list = document.getElementById('plots-list');
        list.innerHTML = state.plots.map(plot => `
            <div class="bg-gradient-to-br from-slate-800/60 to-slate-900/60 backdrop-blur-sm p-4 rounded-xl border border-slate-600/30 shadow-lg hover:shadow-xl transition-all duration-300 hover:border-cyan-400/30 group">
                <div class="flex items-start gap-3">
                    <div class="w-3 h-3 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full shadow-sm mt-1 flex-shrink-0"></div>
                    <p class="text-slate-300 text-sm leading-relaxed group-hover:text-cyan-300 transition-colors">${plot.description}</p>
                </div>
            </div>
        `).join('');
        renderDraggables();
    }

    function renderDraggables() {
        const sources = document.getElementById('draggable-sources');
        sources.innerHTML = `
            <div class="text-center mb-6">
                <h4 class="font-serif text-slate-300 text-lg mb-2">可用的丝线</h4>
                <p class="text-slate-500 text-sm">拖拽下方元素到梭子中进行编织</p>
            </div>
            <div class="flex flex-wrap justify-center gap-3">
                ${state.plots.map(p => `
                    <div draggable="true" class="draggable-item group p-3 bg-gradient-to-br from-slate-700/80 to-slate-800/80 backdrop-blur-sm rounded-xl cursor-grab active:cursor-grabbing hover:from-slate-600/80 hover:to-slate-700/80 border border-slate-600/30 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 hover:border-cyan-400/50" data-type="plot" data-item='${JSON.stringify(p)}'>
                        <div class="flex items-center gap-2">
                            <div class="w-2 h-2 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full shadow-sm"></div>
                            <span class="text-cyan-300 font-medium text-sm">情节:</span>
                        </div>
                        <p class="text-slate-300 text-sm mt-1 group-hover:text-cyan-200 transition-colors">${p.description}</p>
                    </div>
                `).join('')}
                ${state.characters.map(c => `
                    <div draggable="true" class="draggable-item group p-3 bg-gradient-to-br from-slate-700/80 to-slate-800/80 backdrop-blur-sm rounded-xl cursor-grab active:cursor-grabbing hover:from-slate-600/80 hover:to-slate-700/80 border border-slate-600/30 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 hover:border-amber-400/50" data-type="character" data-item='${JSON.stringify(c)}'>
                        <div class="flex items-center gap-2">
                            <div class="w-2 h-2 bg-gradient-to-r from-amber-400 to-orange-500 rounded-full shadow-sm"></div>
                            <span class="text-amber-300 font-medium text-sm">角色:</span>
                        </div>
                        <p class="text-slate-300 text-sm mt-1 group-hover:text-amber-200 transition-colors">${c.name}</p>
                        ${c.keywords.length > 0 ? `<div class="flex flex-wrap gap-1 mt-2">${c.keywords.slice(0, 3).map(kw => `<span class="text-xs px-2 py-0.5 rounded-full bg-slate-600/50 text-slate-400">${kw}</span>`).join('')}${c.keywords.length > 3 ? '<span class="text-xs text-slate-500">...</span>' : ''}</div>` : ''}
                    </div>
                `).join('')}
            </div>
        `;
        addDragAndDropListeners();
    }

    // Initial renders
    renderCharacters();
    renderPlots();
    updateShuttleView();

    // --- Event Listeners ---
    document.getElementById('add-char-form').addEventListener('submit', e => {
        e.preventDefault();
        const input = document.getElementById('char-name-input');
        if (input.value.trim()) {
            state.characters.push({ id: Date.now(), name: input.value.trim(), keywords: [] });
            input.value = '';
            renderCharacters();
        }
    });

    document.getElementById('add-plot-form').addEventListener('submit', e => {
        e.preventDefault();
        const input = document.getElementById('plot-desc-input');
        if (input.value.trim()) {
            state.plots.push({ id: Date.now(), description: input.value.trim() });
            input.value = '';
            renderPlots();
        }
    });

    document.getElementById('characters-list').addEventListener('keydown', e => {
        if (e.key === 'Enter' && e.target.classList.contains('keyword-input')) {
            e.preventDefault();
            const charId = parseInt(e.target.dataset.charId);
            const keyword = e.target.value.trim();
            if (keyword) {
                const char = state.characters.find(c => c.id === charId);
                if (char) {
                    char.keywords.push(keyword);
                    e.target.value = '';
                    renderCharacters();
                }
            }
        }
    });

    function addDragAndDropListeners() {
        const draggables = document.querySelectorAll('.draggable-item');
        const shuttle = document.getElementById('droppable-shuttle');

        draggables.forEach(draggable => {
            draggable.addEventListener('dragstart', (e) => {
                e.dataTransfer.setData('application/json', e.target.dataset.item);
                e.dataTransfer.setData('text/plain', e.target.dataset.type);
                setTimeout(() => e.target.classList.add('opacity-50'), 0);
            });
            draggable.addEventListener('dragend', (e) => {
                 e.target.classList.remove('opacity-50');
            });
        });

        shuttle.addEventListener('dragover', (e) => {
            e.preventDefault();
            shuttle.classList.replace('border-slate-600', 'border-amber-400');
            shuttle.classList.add('bg-amber-400/10');
        });
        shuttle.addEventListener('dragleave', (e) => {
            shuttle.classList.replace('border-amber-400', 'border-slate-600');
            shuttle.classList.remove('bg-amber-400/10');
        });
        shuttle.addEventListener('drop', (e) => {
            e.preventDefault();
            shuttle.classList.replace('border-amber-400', 'border-slate-600');
            shuttle.classList.remove('bg-amber-400/10');
            
            const type = e.dataTransfer.getData('text/plain');
            const item = JSON.parse(e.dataTransfer.getData('application/json'));

            if (type === 'plot') {
                // 检查是否已存在相同ID的情节，避免重复添加
                if (!shuttleContent.plots.some(p => p.id === item.id)) {
                    shuttleContent.plots.push(item);
                }
            } else if (type === 'character') {
                if (!shuttleContent.chars.some(c => c.id === item.id)) {
                    shuttleContent.chars.push(item);
                }
            }
            updateShuttleView();
        });
    }

    document.getElementById('weave-button').addEventListener('click', async () => {
        if (shuttleContent.plots.length === 0 || shuttleContent.chars.length === 0) {
            // A simple modal can be implemented here instead of alert
            alert("请将至少一个情节和一位角色放入梭子中。");
            return;
        }

        const button = document.getElementById('weave-button');
        button.disabled = true;
        button.innerHTML = `<div class="w-5 h-5 border-2 border-slate-900 border-t-transparent rounded-full animate-spin"></div>织造中...`;

        const charDesc = shuttleContent.chars.map(c => `${c.name} (${c.keywords.join(', ')})`).join('; ');
        const plotDesc = shuttleContent.plots.map(p => p.description).join('；');
        const prompt = `
            请基于以下设定，创作一段富有想象力的故事：
            ### 经线 (世界框架)
            - **时代:** ${state.warp.era.name} (${state.warp.era.description})
            - **世界:** ${state.warp.world.name} (${state.warp.world.description})
            - **故事风格/纹理:** ${state.warp.style.name}
            ### 纬线 (当前情节)
            - **事件:** ${plotDesc}
            ### 丝线 (出场角色)
            - **角色:** ${charDesc}
            请以生动、符合所选风格的文笔，编织出接下来发生的故事。`;

        try {
            // 配置Gemini 2.5 Flash API
            const apiKey = "AIzaSyDsbMOApPK4NCJEl0JQ1S95Dajv-zL4XR4";
            const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;

            // 构建请求payload
            const payload = {
                contents: [{
                    role: "user",
                    parts: [{ text: prompt }]
                }],
                generationConfig: {
                    temperature: 0.8,
                    topK: 40,
                    topP: 0.95,
                    maxOutputTokens: 2048,
                },
                safetySettings: [
                    {
                        category: "HARM_CATEGORY_HARASSMENT",
                        threshold: "BLOCK_MEDIUM_AND_ABOVE"
                    },
                    {
                        category: "HARM_CATEGORY_HATE_SPEECH",
                        threshold: "BLOCK_MEDIUM_AND_ABOVE"
                    },
                    {
                        category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                        threshold: "BLOCK_MEDIUM_AND_ABOVE"
                    },
                    {
                        category: "HARM_CATEGORY_DANGEROUS_CONTENT",
                        threshold: "BLOCK_MEDIUM_AND_ABOVE"
                    }
                ]
            };

            console.log("正在调用Gemini 2.5 Flash API...", { apiUrl, payload });

            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (compatible; InspirationLoom/1.0)'
                },
                body: JSON.stringify(payload)
            });

            console.log("API响应状态:", response.status, response.statusText);

            if (!response.ok) {
                const errorText = await response.text();
                console.error("API错误详情:", errorText);
                throw new Error(`API调用失败 (状态码: ${response.status}): ${errorText}`);
            }

            const result = await response.json();
            console.log("API响应结果:", result);

            if (result.candidates && result.candidates[0]?.content?.parts?.[0]?.text) {
                const generatedText = result.candidates[0].content.parts[0].text;
                state.storyText += "\n\n" + generatedText;
                console.log("故事生成成功，长度:", generatedText.length);
            } else {
                console.error("API响应格式异常:", result);
                throw new Error("未能从API获取有效的故事内容。请检查API响应格式。");
            }

        } catch (error) {
            console.error("故事生成失败:", error);

            // 提供更详细的错误信息
            let errorMessage = "生成故事时发生错误：";
            if (error.message.includes('403')) {
                errorMessage += "API密钥无效或权限不足";
            } else if (error.message.includes('429')) {
                errorMessage += "API调用频率超限，请稍后重试";
            } else if (error.message.includes('500')) {
                errorMessage += "服务器内部错误，请稍后重试";
            } else {
                errorMessage += error.message;
            }

            state.storyText += `\n\n// ${errorMessage}`;
        } finally {
            state.stage = 'result';
            render();
        }
    });
}


// 内联SVG图标
const SVG_ICONS = {
  ArrowLeft: '<svg class="w-4 h-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>',
  Download: '<svg class="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
  Share2: '<svg class="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>',
  BookOpen: '<svg class="w-6 h-6 text-purple-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 19V6a2 2 0 0 1 2-2h7"/><path d="M22 19V6a2 2 0 0 0-2-2h-7"/><path d="M2 19a2 2 0 0 0 2 2h7"/><path d="M22 19a2 2 0 0 1-2 2h-7"/><line x1="12" y1="4" x2="12" y2="20"/></svg>',
  Sparkles: '<svg class="w-6 h-6 text-purple-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v2"/><path d="M12 19v2"/><path d="M5.22 5.22l1.42 1.42"/><path d="M17.36 17.36l1.42 1.42"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="M5.22 18.78l1.42-1.42"/><path d="M17.36 6.64l1.42-1.42"/><circle cx="12" cy="12" r="5"/></svg>',
  Star: '<svg class="w-5 h-5 text-purple-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
  Scroll: '<svg class="w-6 h-6 text-purple-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 22H7a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2z"/><path d="M7 2v20"/><path d="M17 2v20"/></svg>',
  Play: '<svg class="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>',
  RotateCcw: '<svg class="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>',
};

// 渲染Completion页面
function renderCompletionPage(storyData, metricsData) {
  // storyData: { characters, plot, generatedStory }
  // metricsData: [{ label, value, color }]

  const storyElements = [
    {
      id: "characters",
      label: "角色",
      content: storyData.characters,
      icon: `<svg class="w-5 h-5" style="filter: drop-shadow(0 0 4px rgba(59, 130, 246, 0.6))" fill="none" stroke="#60a5fa" stroke-width="1.5" viewBox="0 0 24 24">
        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
        <circle cx="12" cy="7" r="4"/>
      </svg>`
    },
    {
      id: "plot",
      label: "情节",
      content: storyData.plot,
      icon: `<svg class="w-5 h-5" style="filter: drop-shadow(0 0 4px rgba(34, 197, 94, 0.6))" fill="none" stroke="#4ade80" stroke-width="1.5" viewBox="0 0 24 24">
        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
      </svg>`
    },
    {
      id: "theme",
      label: "主题",
      content: "命运与选择的交织",
      icon: `<svg class="w-5 h-5" style="filter: drop-shadow(0 0 4px rgba(249, 115, 22, 0.6))" fill="none" stroke="#fb923c" stroke-width="1.5" viewBox="0 0 24 24">
        <polyline points="14.5,17.5 3,6 3,3 6,3 17.5,14.5"/>
        <line x1="13" y1="19" x2="19" y2="13"/>
        <line x1="16" y1="16" x2="20" y2="20"/>
        <line x1="19" y1="21" x2="21" y2="19"/>
      </svg>`
    },
    {
      id: "setting",
      label: "背景",
      content: "神秘的星际世界",
      icon: `<svg class="w-5 h-5" style="filter: drop-shadow(0 0 4px rgba(168, 85, 247, 0.6))" fill="none" stroke="#a855f7" stroke-width="1.5" viewBox="0 0 24 24">
        <polygon points="3,6 9,3 15,6 21,3 21,18 15,21 9,18 3,21"/>
        <line x1="9" y1="3" x2="9" y2="18"/>
        <line x1="15" y1="6" x2="15" y2="21"/>
      </svg>`
    },
  ];

  // 默认选中第一个
  let selectedElement = storyElements[0].id;
  const selectedDetail = storyElements.find(e => e.id === selectedElement);

  // 生成故事段落
  const storyParagraphs = storyData.generatedStory.split("。")
    .map(s => s.trim())
    .filter(Boolean)
    .map((sentence, i) => `<p class="mb-4 text-slate-200 leading-relaxed" style="animation-delay: ${i * 0.5}s">${sentence}。</p>`)
    .join("");

  // 注意：现在使用固定布局，不需要动态生成HTML

  // 主HTML - 全屏布局
  return `
    <div class="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-800 relative">

      <!-- 背景星尘 -->
      <div class="absolute inset-0 overflow-hidden pointer-events-none">
        <div class="absolute top-[10%] left-[15%] w-2 h-2 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 4s;"></div>
        <div class="absolute top-[25%] right-[20%] w-1 h-1 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 6s;"></div>
        <div class="absolute top-[40%] left-[8%] w-1.5 h-1.5 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 5s;"></div>
        <div class="absolute top-[60%] right-[12%] w-1 h-1 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 7s;"></div>
        <div class="absolute top-[75%] left-[25%] w-2 h-2 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 4.5s;"></div>
        <div class="absolute top-[15%] left-[60%] w-1 h-1 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 6.5s;"></div>
        <div class="absolute top-[35%] right-[35%] w-1.5 h-1.5 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 5.5s;"></div>
        <div class="absolute top-[80%] right-[40%] w-1 h-1 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 7.5s;"></div>
        <div class="absolute top-[20%] left-[80%] w-2 h-2 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 4.2s;"></div>
        <div class="absolute top-[65%] left-[70%] w-1.5 h-1.5 rounded-full bg-white opacity-20 animate-pulse" style="animation-duration: 6.8s;"></div>
      </div>

      <!-- 顶部导航栏 -->
      <div class="flex items-center justify-between p-4 border-b border-slate-700/50 bg-slate-900/80 backdrop-blur-sm relative z-50">
        <button id="back-to-creation" class="flex items-center text-slate-300 hover:text-white transition-colors">
          <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
          </svg>
          返回创作
        </button>
        <div class="flex items-center gap-2 text-green-400">
          <div class="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span class="text-sm">故事织造完成</span>
        </div>
        <div class="text-slate-400 text-sm">数据流稳定</div>
      </div>

      <!-- 主内容区域 -->
      <div class="flex-1 p-6 overflow-auto">
        <!-- 主仪表板容器 - 横向Flexbox，增大间距 -->
        <div id="main-dashboard" class="flex gap-8 w-full max-w-6xl mx-auto relative z-10">

          <!-- 左列：故事星图 + 故事纹理 -->
          <div class="flex flex-col gap-6 w-80 flex-shrink-0">

            <!-- 故事星图面板 -->
            <div class="relative bg-slate-800/50 backdrop-blur-lg rounded-2xl p-6 before:absolute before:inset-0 before:bg-gradient-to-br before:from-white/20 before:to-transparent before:rounded-2xl before:pointer-events-none">
              <!-- 标题 -->
              <div class="relative z-10 flex items-center gap-2 mb-6">
                <svg class="w-5 h-5 text-purple-400" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                </svg>
                <h3 class="text-lg font-semibold text-white">故事星图</h3>
              </div>

              <!-- 星座图区域 -->
              <div class="relative z-10 h-48 bg-slate-900/50 rounded-xl border border-slate-700/30 mb-4 flex items-center justify-center">
                <!-- 中心大图标 - 指南针 -->
                <div class="w-16 h-16 rounded-full flex items-center justify-center cursor-pointer hover:scale-110 transition-transform">
                  <svg class="w-12 h-12" style="filter: drop-shadow(0 0 8px rgba(139, 92, 246, 0.6))" fill="none" stroke="#a78bfa" stroke-width="1.5" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10"/>
                    <polygon points="16.24,7.76 14.12,14.12 7.76,16.24 9.88,9.88 16.24,7.76"/>
                  </svg>
                </div>

                <!-- 环绕的四个小图标 -->
                <!-- 顶部 - 用户角色 -->
                <div class="absolute top-4 left-1/2 transform -translate-x-1/2">
                  <div class="w-10 h-10 rounded-full flex items-center justify-center cursor-pointer hover:scale-110 transition-transform">
                    <svg class="w-6 h-6" style="filter: drop-shadow(0 0 6px rgba(59, 130, 246, 0.6))" fill="none" stroke="#60a5fa" stroke-width="1.5" viewBox="0 0 24 24">
                      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                      <circle cx="12" cy="7" r="4"/>
                    </svg>
                  </div>
                </div>

                <!-- 右侧 - 书籍故事 -->
                <div class="absolute right-4 top-1/2 transform -translate-y-1/2">
                  <div class="w-10 h-10 rounded-full flex items-center justify-center cursor-pointer hover:scale-110 transition-transform">
                    <svg class="w-6 h-6" style="filter: drop-shadow(0 0 6px rgba(34, 197, 94, 0.6))" fill="none" stroke="#4ade80" stroke-width="1.5" viewBox="0 0 24 24">
                      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
                      <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
                    </svg>
                  </div>
                </div>

                <!-- 底部 - 剑与冲突 -->
                <div class="absolute bottom-4 left-1/2 transform -translate-x-1/2">
                  <div class="w-10 h-10 rounded-full flex items-center justify-center cursor-pointer hover:scale-110 transition-transform">
                    <svg class="w-6 h-6" style="filter: drop-shadow(0 0 6px rgba(249, 115, 22, 0.6))" fill="none" stroke="#fb923c" stroke-width="1.5" viewBox="0 0 24 24">
                      <polyline points="14.5,17.5 3,6 3,3 6,3 17.5,14.5"/>
                      <line x1="13" y1="19" x2="19" y2="13"/>
                      <line x1="16" y1="16" x2="20" y2="20"/>
                      <line x1="19" y1="21" x2="21" y2="19"/>
                    </svg>
                  </div>
                </div>

                <!-- 左侧 - 地图世界 -->
                <div class="absolute left-4 top-1/2 transform -translate-y-1/2">
                  <div class="w-10 h-10 rounded-full flex items-center justify-center cursor-pointer hover:scale-110 transition-transform">
                    <svg class="w-6 h-6" style="filter: drop-shadow(0 0 6px rgba(168, 85, 247, 0.6))" fill="none" stroke="#a855f7" stroke-width="1.5" viewBox="0 0 24 24">
                      <polygon points="3,6 9,3 15,6 21,3 21,18 15,21 9,18 3,21"/>
                      <line x1="9" y1="3" x2="9" y2="18"/>
                      <line x1="15" y1="6" x2="15" y2="21"/>
                    </svg>
                  </div>
                </div>

                <!-- 连接线 -->
                <svg class="absolute inset-0 w-full h-full pointer-events-none">
                  <defs>
                    <linearGradient id="starLineGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stop-color="#8b5cf6" stop-opacity="0.4"/>
                      <stop offset="100%" stop-color="#ec4899" stop-opacity="0.2"/>
                    </linearGradient>
                  </defs>
                  <line x1="50%" y1="20%" x2="50%" y2="50%" stroke="url(#starLineGradient)" stroke-width="1"/>
                  <line x1="80%" y1="50%" x2="50%" y2="50%" stroke="url(#starLineGradient)" stroke-width="1"/>
                  <line x1="50%" y1="80%" x2="50%" y2="50%" stroke="url(#starLineGradient)" stroke-width="1"/>
                  <line x1="20%" y1="50%" x2="50%" y2="50%" stroke="url(#starLineGradient)" stroke-width="1"/>
                </svg>
              </div>

              <!-- 选中详情卡片 -->
              <div id="cosmic-card-detail" class="bg-slate-900/50 rounded-xl border border-slate-700/30 p-4">
                <h4 class="font-semibold text-white mb-2 flex items-center gap-2">
                  ${selectedDetail.icon}${selectedDetail.label}
                </h4>
                <p class="text-slate-300 text-sm leading-relaxed">${selectedDetail.content}</p>
              </div>
            </div>

            <!-- 故事纹理面板 -->
            <div class="relative bg-slate-800/50 backdrop-blur-lg rounded-2xl p-6 before:absolute before:inset-0 before:bg-gradient-to-br before:from-white/20 before:to-transparent before:rounded-2xl before:pointer-events-none">
              <!-- 标题 -->
              <div class="relative z-10 flex items-center gap-2 mb-6">
                <div class="w-5 h-5 bg-gradient-to-r from-cyan-400 to-purple-500 rounded"></div>
                <h3 class="text-lg font-semibold text-white">故事纹理</h3>
              </div>

              <!-- 波形图 -->
              <div class="relative z-10 mb-6 bg-slate-900/50 rounded-xl p-4">
                <svg class="w-full h-16" viewBox="0 0 300 60" preserveAspectRatio="none">
                  <defs>
                    <linearGradient id="waveGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stop-color="#06b6d4"/>
                      <stop offset="25%" stop-color="#3b82f6"/>
                      <stop offset="50%" stop-color="#8b5cf6"/>
                      <stop offset="75%" stop-color="#ec4899"/>
                      <stop offset="100%" stop-color="#f97316"/>
                    </linearGradient>
                  </defs>
                  <path d="M0,30 Q75,10 150,30 T300,30" stroke="url(#waveGradient)" stroke-width="2" fill="none"/>
                </svg>
              </div>

              <!-- 数据指标进度条 -->
              <div class="relative z-10 space-y-4">
                <!-- 情绪强度 -->
                <div>
                  <div class="flex justify-between items-center mb-2">
                    <span class="text-slate-300 text-sm">情绪强度</span>
                    <span class="text-white font-medium">89%</span>
                  </div>
                  <div class="w-full bg-slate-700/50 rounded-full h-2">
                    <div class="bg-gradient-to-r from-cyan-400 to-blue-500 h-2 rounded-full transition-all duration-1000" style="width: 89%"></div>
                  </div>
                </div>

                <!-- 张力系数 -->
                <div>
                  <div class="flex justify-between items-center mb-2">
                    <span class="text-slate-300 text-sm">张力系数</span>
                    <span class="text-white font-medium">87%</span>
                  </div>
                  <div class="w-full bg-slate-700/50 rounded-full h-2">
                    <div class="bg-gradient-to-r from-purple-400 to-pink-500 h-2 rounded-full transition-all duration-1000" style="width: 87%"></div>
                  </div>
                </div>

                <!-- 沉浸度 -->
                <div>
                  <div class="flex justify-between items-center mb-2">
                    <span class="text-slate-300 text-sm">沉浸度</span>
                    <span class="text-white font-medium">92%</span>
                  </div>
                  <div class="w-full bg-slate-700/50 rounded-full h-2">
                    <div class="bg-gradient-to-r from-green-400 to-emerald-500 h-2 rounded-full transition-all duration-1000" style="width: 92%"></div>
                  </div>
                </div>

                <!-- 完整性 -->
                <div>
                  <div class="flex justify-between items-center mb-2">
                    <span class="text-slate-300 text-sm">完整性</span>
                    <span class="text-white font-medium">95%</span>
                  </div>
                  <div class="w-full bg-slate-700/50 rounded-full h-2">
                    <div class="bg-gradient-to-r from-orange-400 to-red-500 h-2 rounded-full transition-all duration-1000" style="width: 95%"></div>
                  </div>
                </div>
              </div>
            </div>

          </div>

          <!-- 右列：命运织卷核心面板 -->
          <div class="flex-1">
            <div class="relative bg-slate-800/50 backdrop-blur-lg rounded-2xl p-8 h-[calc(100vh-200px)] flex flex-col before:absolute before:inset-0 before:bg-gradient-to-br before:from-white/20 before:to-transparent before:rounded-2xl before:pointer-events-none">

              <!-- 面板顶部：标题和图标 -->
              <div class="relative z-10 flex items-center justify-center gap-3 mb-8">
                <svg class="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                </svg>
                <h1 class="text-2xl font-bold text-white">命运织卷</h1>
                <svg class="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                </svg>
              </div>

              <!-- 中间：故事内容文本区域 -->
              <div class="relative z-10 flex-1 overflow-y-auto mb-6">
                <div class="text-slate-200 leading-relaxed space-y-4">
                  ${storyParagraphs}
                </div>
              </div>

              <!-- 分割线 -->
              <hr class="relative z-10 border-white/10 mb-6">

              <!-- 底部：功能按钮排列 -->
              <div class="relative z-10 flex items-center justify-center gap-6">
                <button class="flex items-center gap-2 px-6 py-3 text-gray-400 hover:text-white hover:bg-white/10 rounded-xl transition-all duration-200">
                  <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clip-rule="evenodd"/>
                  </svg>
                  播放
                </button>

                <button class="flex items-center gap-2 px-6 py-3 text-gray-400 hover:text-white hover:bg-white/10 rounded-xl transition-all duration-200">
                  <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                  </svg>
                  下载
                </button>

                <button class="flex items-center gap-2 px-6 py-3 text-gray-400 hover:text-white hover:bg-white/10 rounded-xl transition-all duration-200">
                  <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z"/>
                  </svg>
                  分享
                </button>

                <button class="reweave-button flex items-center gap-2 px-6 py-3 text-gray-400 hover:text-white hover:bg-white/10 rounded-xl transition-all duration-200">
                  <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                  </svg>
                  重新织造
                </button>
              </div>

            </div>
          </div>

        </div>
      </div>


    </div>
  `;
}

// 替换原有renderResult逻辑
function renderResult() {
  // 组装数据
  const storyData = {
    characters: state.characters.map(c => c.name).join('，'),
    plot: state.plots.map(p => p.description).join('，'),
    generatedStory: state.storyText.trim(),
  };
  const metricsData = [
    { label: "情感强度", value: 89, color: "from-cyan-400 to-blue-500" },
    { label: "张力系数", value: 87, color: "from-purple-400 to-pink-500" },
    { label: "沉浸度", value: 92, color: "from-green-400 to-emerald-500" },
    { label: "完整性", value: 95, color: "from-orange-400 to-red-500" },
  ];
  app.innerHTML = renderCompletionPage(storyData, metricsData);
  // 交互：星点点击
  document.querySelectorAll('.story-star').forEach(star => {
    star.addEventListener('click', function() {
      const id = this.getAttribute('data-id');
      document.querySelectorAll('.story-star').forEach(s => s.classList.remove('active'));
      this.classList.add('active');
      // 更新详情
      const element = [
        { id: "characters", label: "角色", content: storyData.characters, icon: "👤" },
        { id: "plot", label: "情节", content: storyData.plot, icon: "📖" },
        { id: "theme", label: "主题", content: "命运与选择的交织", icon: "⚡" },
        { id: "setting", label: "背景", content: "神秘的星际世界", icon: "🌌" },
      ].find(e => e.id === id);
      document.getElementById('cosmic-card-detail').innerHTML = `
        <div class="p-4">
          <h4 class="font-semibold text-purple-100 mb-2 flex items-center gap-2">
            <span class="text-lg">${element.icon}</span>${element.label}
          </h4>
          <p class="text-purple-200 text-sm leading-relaxed">${element.content}</p>
        </div>
      `;
    });
    });
  // 交互：顶部返回
  document.getElementById('back-to-creation').onclick = () => {
        state.stage = 'creation';
        render();
  };
  // 交互：底部按钮
  document.querySelector('.reweave-button').onclick = () => {
        Object.assign(state, {
            stage: 'setup',
            warp: { era: null, world: null, style: null },
            characters: [],
            plots: [],
            storyText: "",
        });
        render();
  };
  document.querySelector('.download-button').onclick = () => {
    const blob = new Blob([storyData.generatedStory], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'story.txt';
    a.click();
    URL.revokeObjectURL(url);
  };
  document.querySelector('.share-button').onclick = () => {
    if (navigator.share) {
      navigator.share({ title: '我的故事', text: storyData.generatedStory });
    } else {
      alert('当前浏览器不支持Web Share API');
    }
  };
  document.querySelector('.play-button').onclick = () => {
    alert('播放功能待实现');
  };
}

// --- 同步编织动画类 ---
class SynchronizedWeavingAnimation {
    constructor() {
        this.container = document.querySelector('.loom-container');
        this.warpContainer = document.querySelector('.warp-threads');
        this.spindleContainer = document.querySelector('.spindles');
        this.textFabric = document.querySelector('.text-fabric');
        this.fabricOverlay = document.querySelector('.fabric-overlay');
        this.floatingContainer = document.querySelector('.floating-threads');

        this.init();
    }

    init() {
        // 立即创建背景飘动丝线
        this.createFloatingThreads();
        // 延迟开始同步动画
        setTimeout(() => this.startSynchronizedWeaving(), 1500);
    }

    // 创建背景飘动丝线
    createFloatingThreads() {
        for (let i = 0; i < 25; i++) {
            const thread = document.createElement('div');
            thread.className = 'floating-thread';
            thread.style.left = Math.random() * 100 + '%';
            thread.style.top = Math.random() * 100 + '%';
            thread.style.animationDelay = Math.random() * 3 + 's';
            thread.style.animationDuration = (4 + Math.random() * 2) + 's';
            this.floatingContainer.appendChild(thread);
        }
    }

    // 同步编织动画：文字和编织过程一起出现
    startSynchronizedWeaving() {
        // 1. 文字开始浮现
        this.textFabric.style.animation = 'textWeaveSync 3s ease-out forwards';

        // 2. 同时开始经线生长
        this.createWarpThreads();

        // 3. 稍后开始纺锤和光点
        setTimeout(() => this.createSpindlesAndParticles(), 800);

        // 4. 织物纹理最后出现
        setTimeout(() => {
            this.fabricOverlay.style.animation = 'fabricRevealSync 2s ease-out forwards';
        }, 2500);

        // 5. 最终光效
        setTimeout(() => this.addFinalGlow(), 3500);
    }

    // 创建经线
    createWarpThreads() {
        const warpCount = 12;
        const spacing = 45;
        const startX = (600 - spacing * (warpCount - 1)) / 2;

        for (let i = 0; i < warpCount; i++) {
            const warp = document.createElement('div');
            warp.className = 'warp-thread';
            warp.style.left = `${startX + i * spacing}px`;
            warp.style.animationDelay = `${i * 0.1}s`;
            warp.style.animation = 'warpGrowSync 2s ease-out forwards';

            this.warpContainer.appendChild(warp);
        }
    }

    // 创建纺锤和光点粒子
    createSpindlesAndParticles() {
        const spindlePositions = [120, 220, 320, 420];
        const threadColors = ['#FF6B6B', '#4ECDC4', '#FFD93D', '#6BCF7F'];

        spindlePositions.forEach((pos, index) => {
            // 创建光点粒子效果
            this.createLightParticles(pos, threadColors[index]);

            setTimeout(() => {
                // 创建纺锤
                const spindle = document.createElement('div');
                spindle.className = 'spindle';
                spindle.style.left = `${pos}px`;
                spindle.style.animation = 'fadeInSync 1s ease-out forwards';
                this.spindleContainer.appendChild(spindle);

                // 创建缠绕的丝线
                for (let i = 0; i < 4; i++) {
                    const thread = document.createElement('div');
                    thread.className = 'thread';
                    thread.style.background = threadColors[index];
                    thread.style.left = `${pos}px`;
                    thread.style.bottom = `${i * 6}px`;
                    thread.style.transformOrigin = `${2 + Math.random() * 2}px bottom`;
                    thread.style.animationDelay = `${i * 0.2}s`;
                    thread.style.animation = 'threadWindSync 1.5s ease-out forwards';
                    thread.style.boxShadow = `0 0 4px ${threadColors[index]}`;

                    this.spindleContainer.appendChild(thread);
                }
            }, index * 150);
        });
    }

    // 创建光点粒子效果
    createLightParticles(targetPos, color) {
        const particleCount = 6;

        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('div');
            particle.className = 'light-particle';
            particle.style.background = `radial-gradient(circle, ${color}, transparent)`;
            particle.style.boxShadow = `0 0 6px ${color}`;

            // 随机起始位置（从边缘）
            const side = Math.floor(Math.random() * 4);
            let startX, startY;

            switch(side) {
                case 0: startX = Math.random() * window.innerWidth; startY = 0; break;
                case 1: startX = window.innerWidth; startY = Math.random() * window.innerHeight; break;
                case 2: startX = Math.random() * window.innerWidth; startY = window.innerHeight; break;
                case 3: startX = 0; startY = Math.random() * window.innerHeight; break;
            }

            particle.style.left = `${startX}px`;
            particle.style.top = `${startY}px`;
            this.container.appendChild(particle);

            // 动画到目标位置
            setTimeout(() => {
                const weavingArea = document.querySelector('.weaving-area');
                const rect = weavingArea.getBoundingClientRect();

                particle.style.transition = 'all 1.5s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
                particle.style.left = `${rect.left + targetPos}px`;
                particle.style.top = `${rect.bottom - 40}px`;
                particle.style.opacity = '1';

                setTimeout(() => {
                    particle.style.animation = 'particleTravelSync 0.6s ease-out forwards';
                }, 1200);

                setTimeout(() => particle.remove(), 2000);
            }, i * 100);
        }
    }

    // 添加最终光效
    addFinalGlow() {
        const logo = document.querySelector('.logo');
        if (logo) {
            logo.style.filter = 'drop-shadow(0 0 20px rgba(255,255,255,0.4))';

            // 微妙的脉冲效果
            setInterval(() => {
                logo.style.textShadow = `
                    0 0 25px rgba(255,255,255,${0.3 + Math.random() * 0.2}),
                    0 0 50px rgba(255,215,0,${0.1 + Math.random() * 0.1})
                `;
            }, 2000);
        }
    }
}

// --- 初始化应用 ---
// 首次加载时调用主渲染函数
render();

